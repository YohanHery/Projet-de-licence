import time
import heapq
import numpy as np
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


# ============================================================
# OUTILS
# ============================================================

def generer_points(n, seed=None):
    rng = np.random.default_rng(seed)
    return rng.random((n, 2))  # points dans [0,1]^2


def matrice_distances(points):
    """
    Vectorisé: O(n^2) en numpy, beaucoup plus rapide que 2 boucles Python.
    """
    P = np.asarray(points, dtype=float)
    diff = P[:, None, :] - P[None, :, :]
    D = np.sqrt(np.sum(diff * diff, axis=2))
    return D


def longueur_tour(tour, D):
    if not tour or len(tour) < 2:
        return 0.0
    tour = np.asarray(tour, dtype=int)
    nxt = np.roll(tour, -1)
    return float(np.sum(D[tour, nxt]))


def parse_points_file(path):
    pts = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            s = s.replace("(", "").replace(")", "").replace("[", "").replace("]", "")
            s = s.replace(",", " ")
            parts = s.split()
            if len(parts) < 2:
                continue
            x, y = float(parts[0]), float(parts[1])
            pts.append((x, y))

    if len(pts) < 3:
        raise ValueError("Le fichier doit contenir au moins 3 points.")

    return np.array(pts, dtype=float)



# ============================================================
# 1) PPP (insertion près du point du cycle le plus proche)
#    Version "parfaite": insertion du meilleur côté adjacent (avant/après)
# ============================================================

def ppp(points, start=0, D=None):
    n = len(points)
    if n == 0:
        return []
    if D is None:
        D = matrice_distances(points)

    cycle = [start]
    remaining = set(range(n))
    remaining.remove(start)

    while remaining:
        # 1) on choisit p restant le plus proche d'un sommet q du cycle
        best_dist = float("inf")
        best_p = None
        best_i = None  # index de q dans cycle

        for p in remaining:
            # distance de p à chacun des sommets du cycle
            for i, q in enumerate(cycle):
                d = D[p, q]
                if d < best_dist:
                    best_dist = d
                    best_p = p
                    best_i = i

        # 2) insertion entre q et un de ses deux adjacents : on teste les 2 côtés
        # cycle = [..., prev, q, next, ...] (cycle non fermé dans la liste, mais on raisonne modulo)
        m = len(cycle)
        q = cycle[best_i]
        prev_idx = (best_i - 1) % m
        next_idx = (best_i + 1) % m
        prev_v = cycle[prev_idx]
        next_v = cycle[next_idx]

        # insérer entre prev_v - q  => position = best_i (avant q)
        delta_before = D[prev_v, best_p] + D[best_p, q] - D[prev_v, q]
        # insérer entre q - next_v  => position = best_i+1 (après q)
        delta_after = D[q, best_p] + D[best_p, next_v] - D[q, next_v]

        if m == 1:
            # seul sommet dans le cycle, "avant/après" équivalent
            cycle.insert(1, best_p)
        else:
            if delta_before <= delta_after:
                cycle.insert(best_i, best_p)
            else:
                cycle.insert(best_i + 1, best_p)

        remaining.remove(best_p)

    return cycle


# ============================================================
# 2) OptPPP (2-opt / décroisement)
# ============================================================

def opt_ppp(points, start=0, D=None):
    n = len(points)
    if n == 0:
        return []
    if D is None:
        D = matrice_distances(points)

    cycle = ppp(points, start=start, D=D)

    improved = True
    while improved:
        improved = False
        for i in range(n):
            for j in range(i + 2, n):
                # évite de casser l'arête (dernier -> premier)
                if i == 0 and j == n - 1:
                    continue

                a, b = cycle[i], cycle[(i + 1) % n]
                c, d = cycle[j], cycle[(j + 1) % n]

                old = D[a, b] + D[c, d]
                new = D[a, c] + D[b, d]

                if new + 1e-15 < old:
                    cycle[i + 1:j + 1] = reversed(cycle[i + 1:j + 1])
                    improved = True

    return cycle


# ============================================================
# 3) OptPrim (Prim avec heap + parcours DFS préfixe)
# ============================================================

def opt_prim(points, start=0, D=None):
    n = len(points)
    if n == 0:
        return []
    if D is None:
        D = matrice_distances(points)

    visited = [False] * n
    parent = [-1] * n
    key = [float("inf")] * n
    key[start] = 0.0

    pq = [(0.0, start)]
    while pq:
        _, u = heapq.heappop(pq)
        if visited[u]:
            continue
        visited[u] = True

        # graphe complet => on teste tous les v
        du = D[u]  # vue sur la ligne u
        for v in range(n):
            if not visited[v] and du[v] < key[v]:
                key[v] = float(du[v])
                parent[v] = u
                heapq.heappush(pq, (key[v], v))

    tree = [[] for _ in range(n)]
    for v in range(n):
        if parent[v] != -1:
            tree[parent[v]].append(v)

    # petit plus: explorer les enfants par proximité pour souvent améliorer
    for u in range(n):
        tree[u].sort(key=lambda v: D[u, v])

    tour = []

    def dfs(u):
        tour.append(u)
        for w in tree[u]:
            dfs(w)

    dfs(start)
    return tour


# ============================================================
# 4) HDS exact (Branch & Bound best-first + borne demi-somme)
#    IMPORTANT : exact, exponentiel (à utiliser pour n <= 10)
# ============================================================

def HDS(points):
    n = len(points)
    if n <= 1:
        return list(range(n))

    D = matrice_distances(points)

    # Pré-calcule, pour chaque sommet, les 2 plus petites arêtes incidentes
    two_min = []
    for i in range(n):
        vals = np.sort(D[i][D[i] > 0.0])  # exclut D[i,i]=0
        two_min.append((float(vals[0]), float(vals[1])))

    def lower_bound(path, cost_so_far):
        """
        Borne demi-somme:
        - non visités: + (min1+min2)
        - extrémités du chemin: + min1 chacune
        puis /2
        """
        used = set(path)
        lb = cost_so_far

        for v in range(n):
            if v not in used:
                lb += two_min[v][0] + two_min[v][1]

        start = path[0]
        end = path[-1]
        lb += two_min[start][0]
        lb += two_min[end][0]

        return lb / 2.0

    # UB initial via OptPPP
    ub_tour = opt_ppp(points, start=0, D=D)
    best_cost = longueur_tour(ub_tour, D)
    best_tour = ub_tour

    pq = []
    start_path = [0]
    heapq.heappush(pq, (lower_bound(start_path, 0.0), 0.0, start_path))

    while pq:
        bnd, cost, path = heapq.heappop(pq)
        if bnd >= best_cost:
            continue

        if len(path) == n:
            total = cost + float(D[path[-1], path[0]])
            if total < best_cost:
                best_cost = total
                best_tour = path
            continue

        used = set(path)
        last = path[-1]

        # ordre des successeurs: proches d'abord (souvent accélère)
        candidates = [v for v in range(n) if v not in used]
        candidates.sort(key=lambda v: D[last, v])

        for nxt in candidates:
            new_cost = cost + float(D[last, nxt])
            if new_cost >= best_cost:
                continue
            new_path = path + [nxt]
            new_bnd = lower_bound(new_path, new_cost)
            if new_bnd < best_cost:
                heapq.heappush(pq, (new_bnd, new_cost, new_path))

    return best_tour


# ============================================================
# ÉTUDE STATISTIQUE (100 essais)
# ============================================================

def stats_100(n, include_hds=False, seed0=0):
    """
    Retourne:
    - moyennes des longueurs PPP / OptPPP / OptPrim (et HDS si demandé et n<=10)
    - gains %
    """
    L_ppp, L_opt, L_prm, L_hds = [], [], [], []
    for k in range(100):
        pts = generer_points(n, seed=seed0 + k)
        D = matrice_distances(pts)

        t1 = ppp(pts, start=0, D=D)
        t2 = opt_ppp(pts, start=0, D=D)
        t3 = opt_prim(pts, start=0, D=D)

        L_ppp.append(longueur_tour(t1, D))
        L_opt.append(longueur_tour(t2, D))
        L_prm.append(longueur_tour(t3, D))

        if include_hds and n <= 10:
            th = HDS(pts)
            L_hds.append(longueur_tour(th, D))

    mean_ppp = float(np.mean(L_ppp))
    mean_opt = float(np.mean(L_opt))
    mean_prm = float(np.mean(L_prm))

    gain_opt_vs_ppp = 100.0 * (mean_ppp - mean_opt) / mean_ppp if mean_ppp > 0 else 0.0
    gain_prm_vs_opt = 100.0 * (mean_opt - mean_prm) / mean_opt if mean_opt > 0 else 0.0

    out = {
        "mean": {
            "PPP": mean_ppp,
            "OptPPP": mean_opt,
            "OptPrim": mean_prm,
        },
        "gain_%": {
            "OptPPP vs PPP": gain_opt_vs_ppp,
            "OptPrim vs OptPPP": gain_prm_vs_opt,
        }
    }

    if include_hds and n <= 10 and len(L_hds) == 100:
        mean_hds = float(np.mean(L_hds))
        out["mean"]["HDS"] = mean_hds
        out["gap_%"] = {
            "PPP vs HDS": 100.0 * (mean_ppp - mean_hds) / mean_hds if mean_hds > 0 else 0.0,
            "OptPPP vs HDS": 100.0 * (mean_opt - mean_hds) / mean_hds if mean_hds > 0 else 0.0,
            "OptPrim vs HDS": 100.0 * (mean_prm - mean_hds) / mean_hds if mean_hds > 0 else 0.0,
        }

    return out


# ============================================================
# GUI
# ============================================================

class TSPGui:
    def __init__(self, root):
        self.root = root
        self.root.title("PVC – PPP / OptPPP / OptPrim / HDS + Fichier + Stats100")

        self.points = None
        self.D = None
        self.tour = None
        self.current_title = None

        # --- TOP BAR
        top = ttk.Frame(root, padding=10)
        top.pack(side=tk.TOP, fill=tk.X)

        ttk.Label(top, text="n :").pack(side=tk.LEFT)
        self.n_var = tk.StringVar(value="20")
        ttk.Entry(top, width=6, textvariable=self.n_var).pack(side=tk.LEFT, padx=5)

        ttk.Label(top, text="seed :").pack(side=tk.LEFT, padx=(10, 0))
        self.seed_var = tk.StringVar(value="0")
        ttk.Entry(top, width=8, textvariable=self.seed_var).pack(side=tk.LEFT, padx=5)

        ttk.Button(top, text="Générer", command=self.generate).pack(side=tk.LEFT, padx=8)
        ttk.Button(top, text="Charger fichier...", command=self.load_file).pack(side=tk.LEFT, padx=2)

        ttk.Separator(top, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)

        ttk.Button(top, text="PPP", command=lambda: self.run_algo("PPP")).pack(side=tk.LEFT)
        ttk.Button(top, text="OptPPP", command=lambda: self.run_algo("OptPPP")).pack(side=tk.LEFT, padx=5)
        ttk.Button(top, text="OptPrim", command=lambda: self.run_algo("OptPrim")).pack(side=tk.LEFT)
        ttk.Button(top, text="HDS (exact)", command=lambda: self.run_algo("HDS")).pack(side=tk.LEFT, padx=5)

        ttk.Separator(top, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)

        ttk.Button(top, text="Étude 100 essais", command=self.run_stats_100).pack(side=tk.LEFT, padx=2)

        self.include_hds_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(top, text="inclure HDS (si n≤10)", variable=self.include_hds_var).pack(side=tk.LEFT, padx=8)

        self.info = tk.StringVar(value="Génère/charge des points puis choisis un algorithme.")
        ttk.Label(root, textvariable=self.info, padding=(10, 0)).pack(anchor="w")

        # Progress
        self.pbar = ttk.Progressbar(root, mode="determinate", maximum=100)
        self.pbar.pack(fill=tk.X, padx=10, pady=(5, 0))
        self.pbar["value"] = 0

        # --- MAIN AREA
        main = ttk.Frame(root, padding=10)
        main.pack(fill=tk.BOTH, expand=True)

        left = ttk.Frame(main)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        ttk.Separator(main, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)

        right = ttk.Frame(main)
        right.pack(side=tk.LEFT, fill=tk.BOTH)

        # --- TOUR FIGURE
        self.fig_tour = Figure(figsize=(6, 5))
        self.ax_tour = self.fig_tour.add_subplot(111)
        self.canvas_tour = FigureCanvasTkAgg(self.fig_tour, left)
        self.canvas_tour.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # --- BAR FIGURE
        self.fig_bar = Figure(figsize=(4.2, 5))
        self.ax_bar = self.fig_bar.add_subplot(111)
        self.canvas_bar = FigureCanvasTkAgg(self.fig_bar, right)
        self.canvas_bar.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        self.generate()

    def parse_n(self):
        try:
            n = int(self.n_var.get())
            if n < 3:
                raise ValueError
            return n
        except Exception:
            messagebox.showerror("Erreur", "n doit être un entier ≥ 3")
            return None

    def parse_seed(self):
        try:
            return int(self.seed_var.get())
        except Exception:
            return 0

    def set_points(self, pts):
        self.points = np.asarray(pts, dtype=float)
        self.D = matrice_distances(self.points)
        self.tour = None
        self.current_title = None
    
        # Cache des tournées pour éviter des recalculs inutiles dans les barres
        self.cache = {}
    
        self.draw_tour(None)
        self.update_bars_single()
        self.pbar["value"] = 0


    def generate(self):
        n = self.parse_n()
        if n is None:
            return
        seed = self.parse_seed()
        pts = generer_points(n, seed=seed)
        self.set_points(pts)
        self.info.set(f"{n} points générés (seed={seed}).")

    def load_file(self):
        path = filedialog.askopenfilename(
            title="Choisir un fichier de points",
            filetypes=[("Text files", "*.txt *.dat *.csv"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            pts = parse_points_file(path)
            self.n_var.set(str(len(pts)))
            self.set_points(pts)
            self.info.set(f"{len(pts)} points chargés depuis fichier.")
        except Exception as e:
            messagebox.showerror("Erreur fichier", str(e))

    def run_algo(self, name):
        if self.points is None:
            self.info.set("Génère/charge d'abord des points.")
            return
    
        if name == "HDS" and len(self.points) > 10:
            messagebox.showwarning(
                "HDS – limitation",
                "HDS est exact et exponentiel.\nPour éviter le blocage, utilisez n ≤ 10."
            )
            return
    
        t0 = time.perf_counter()
    
        if name == "PPP":
            self.tour = ppp(self.points, start=0, D=self.D)
        elif name == "OptPPP":
            self.tour = opt_ppp(self.points, start=0, D=self.D)
        elif name == "OptPrim":
            self.tour = opt_prim(self.points, start=0, D=self.D)
        elif name == "HDS":
            self.tour = HDS(self.points)
        else:
            return
    
        t1 = time.perf_counter()
        L = longueur_tour(self.tour, self.D)
    
        self.current_title = name
    
        # Mémorisation pour update_bars_single()
        if hasattr(self, "cache"):
            self.cache[name] = list(self.tour)
    
        self.info.set(f"{name} | longueur = {L:.4f} | temps = {(t1 - t0)*1000:.2f} ms")
        self.draw_tour(name)
        self.update_bars_single()


    def draw_tour(self, title):
        self.ax_tour.clear()
    
        # Normalisation UNIQUEMENT pour l'affichage (ne touche pas aux calculs)
        P = np.asarray(self.points, dtype=float)
        minv = P.min(axis=0)
        maxv = P.max(axis=0)
        span = np.maximum(maxv - minv, 1e-12)
        Pn = (P - minv) / span
    
        self.ax_tour.set_xlim(0, 1)
        self.ax_tour.set_ylim(0, 1)
        self.ax_tour.set_title(title if title else "Tournée")
    
        xs = Pn[:, 0]
        ys = Pn[:, 1]
        self.ax_tour.plot(xs, ys, "o")
    
        if self.tour:
            t = self.tour
            x = [Pn[i, 0] for i in t] + [Pn[t[0], 0]]
            y = [Pn[i, 1] for i in t] + [Pn[t[0], 1]]
            self.ax_tour.plot(x, y, "-o")
    
        self.canvas_tour.draw()


    def update_bars_single(self):
        """
        Comparaison sur l'instance courante (sans HDS pour éviter freeze).
        Utilise un cache si disponible pour éviter des recalculs.
        """
        if self.points is None:
            return
    
        self.ax_bar.clear()
        labels = ["PPP", "OptPPP", "OptPrim"]
    
        cache = getattr(self, "cache", {})
    
        t_ppp = cache.get("PPP") or ppp(self.points, start=0, D=self.D)
        t_opt = cache.get("OptPPP") or opt_ppp(self.points, start=0, D=self.D)
        t_prm = cache.get("OptPrim") or opt_prim(self.points, start=0, D=self.D)
    
        vals = [
            longueur_tour(t_ppp, self.D),
            longueur_tour(t_opt, self.D),
            longueur_tour(t_prm, self.D),
        ]
    
        bars = self.ax_bar.bar(labels, vals)
        self.ax_bar.set_title("Longueurs (instance courante)")
        self.ax_bar.set_ylabel("Longueur")
    
        for r, v in zip(bars, vals):
            self.ax_bar.text(r.get_x() + r.get_width() / 2, v, f"{v:.2f}",
                             ha="center", va="bottom", fontsize=9)
    
        self.ax_bar.set_ylim(0, max(vals) * 1.15 if max(vals) > 0 else 1.0)
        self.canvas_bar.draw()


    def run_stats_100(self):
        n = self.parse_n()
        if n is None:
            return

        include_hds = bool(self.include_hds_var.get())
        seed0 = self.parse_seed()

        if include_hds and n > 10:
            # On ne bloque pas : on fait l'étude sans HDS
            include_hds = False

        self.info.set("Étude 100 essais en cours...")
        self.root.update_idletasks()

        # On fait la boucle ici pour afficher la progression
        L_ppp, L_opt, L_prm, L_hds = [], [], [], []
        for k in range(100):
            pts = generer_points(n, seed=seed0 + k)
            D = matrice_distances(pts)

            L_ppp.append(longueur_tour(ppp(pts, 0, D), D))
            L_opt.append(longueur_tour(opt_ppp(pts, 0, D), D))
            L_prm.append(longueur_tour(opt_prim(pts, 0, D), D))

            if include_hds and n <= 10:
                L_hds.append(longueur_tour(HDS(pts), D))

            self.pbar["value"] = k + 1
            self.root.update_idletasks()

        mean_ppp = float(np.mean(L_ppp))
        mean_opt = float(np.mean(L_opt))
        mean_prm = float(np.mean(L_prm))

        gain_opt_vs_ppp = 100.0 * (mean_ppp - mean_opt) / mean_ppp if mean_ppp > 0 else 0.0
        gain_prm_vs_opt = 100.0 * (mean_opt - mean_prm) / mean_opt if mean_opt > 0 else 0.0

        means = [mean_ppp, mean_opt, mean_prm]
        labels = ["PPP", "OptPPP", "OptPrim"]

        extra_text = f" | gains: OptPPP vs PPP = {gain_opt_vs_ppp:.2f}% ; OptPrim vs OptPPP = {gain_prm_vs_opt:.2f}%"

        if include_hds and n <= 10 and len(L_hds) == 100:
            mean_hds = float(np.mean(L_hds))
            labels.append("HDS")
            means.append(mean_hds)
            gap_opt_vs_hds = 100.0 * (mean_opt - mean_hds) / mean_hds if mean_hds > 0 else 0.0
            extra_text += f" | écart OptPPP vs HDS = {gap_opt_vs_hds:.2f}%"

        # Affichage barres des moyennes
        self.ax_bar.clear()
        bars = self.ax_bar.bar(labels, means)
        self.ax_bar.set_title("Moyennes sur 100 essais")
        self.ax_bar.set_ylabel("Longueur moyenne")

        for r, v in zip(bars, means):
            self.ax_bar.text(r.get_x() + r.get_width() / 2, v, f"{v:.2f}",
                             ha="center", va="bottom", fontsize=9)

        self.ax_bar.set_ylim(0, max(means) * 1.15 if max(means) > 0 else 1.0)
        self.canvas_bar.draw()

        self.info.set(
            f"Stats100 (n={n}, seed0={seed0}) | "
            f"moy: PPP={mean_ppp:.2f} OptPPP={mean_opt:.2f} OptPrim={mean_prm:.2f}"
            + (f" HDS={means[-1]:.2f}" if (len(means) == 4) else "")
            + extra_text
        )


# ============================================================
# LANCEMENT
# ============================================================

if __name__ == "__main__":
    root = tk.Tk()
    try:
        style = ttk.Style()
        if "clam" in style.theme_names():
            style.theme_use("clam")
    except Exception:
        pass

    app = TSPGui(root)
    root.mainloop()
