package serie03;

import serie03.cmd.Command;
import serie03.cmd.CommandFactory;
import serie03.text.StdText;
import serie03.text.Text;
import serie03.util.History;
import serie03.util.StdHistory;
import util.Contract;

public class StdEditor implements Editor {
	private Text text;
	private History<Command> history;
	
	public StdEditor(){
		this(DEFAULT_HISTORY_SIZE);
	}
	
	public StdEditor( int historySize) {
		Contract.checkCondition(historySize > 0, "L'historique est vide");
		history = new StdHistory<Command>(historySize);
		text = new StdText();
	}
	
	@Override
	public int getTextLinesNb() {
		return text.getLinesNb();
	}

	@Override
	public String getTextContent() {
		return text.getContent();
	}

	@Override
	public int getHistorySize() {
		return history.getMaxHeight();
	}

	@Override
	public int nbOfPossibleUndo() {
		return history.getCurrentPosition();
	}

	@Override
	public int nbOfPossibleRedo() {
		return  (history.getEndPosition() - history.getCurrentPosition());
	}

	@Override
	public void clear() {
		Command cmd = CommandFactory.createClear(text);
		cmd.act();
		history.add(cmd);
	}

	@Override
	public void insertLine(int numLine, String s) {
        Contract.checkCondition(s != null, "La chaîne à insérer est nulle");
        Command cmd = CommandFactory.createInsertLine(text, numLine, s);
        cmd.act();
        history.add(cmd);
	}

	@Override
	public void deleteLine(int numLine) {
        Contract.checkCondition(numLine >= 1 && numLine <= text.getLinesNb(),
                "numLine n’est pas valide (" + numLine + ")");
        Command cmd = CommandFactory.createDeleteLine(text, numLine);
        cmd.act();
        history.add(cmd);
	}

	@Override
	public void redo() {
        Contract.checkCondition(nbOfPossibleUndo() > 0, "Aucune commande à annuler");
        history.goForward();
        Command cmd = history.getCurrentElement();
        cmd.act();
	}

	@Override
	public void undo() {
        Contract.checkCondition(nbOfPossibleRedo() > 0, "Aucune commande à rejouer");
        history.goBackward();
        Command cmd = history.getCurrentElement();
        cmd.act(); 
	}

}
