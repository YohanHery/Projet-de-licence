package serie03.util;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import util.Contract;

public class StdHistory<E> implements History<E> {
	
	private final int mHeight;
	private final List<E> history;
	private ListIterator<E> iterator;
	
	public StdHistory(int maxHeight) {
		Contract.checkCondition(maxHeight > 0, "maxHeight doit être supérieur 0");
		mHeight = maxHeight;
		history = new LinkedList<E>();
		iterator = history.listIterator();
	}
    
    public int getMaxHeight() {
    	return mHeight;
    }
   
    /**
     * La position courante dans l'historique.
     */
    public int getCurrentPosition() {
    	return iterator.nextIndex();
    }
    
    /**
     * L'élément de l'historique, désigné par la position courante.
     * @pre <pre>
     *     getCurrentPosition() > 0 </pre>
     */
    public E getCurrentElement() {
    	Contract.checkCondition(getCurrentPosition() > 0, "Position incorrecte");
    	E val = iterator.previous();
    	iterator.next();
    	return val;
    }
    
    /**
     * La position du dernier élément de l'historique.
     */
    public int getEndPosition() {
    	return history.size();
    }
    
    /**
     * Indique si cet historique est vide.
     */
    public boolean isEmpty() {
    	return history.size() == 0;
    }

    // COMMANDES
    
    /**
     * Ajoute l'élément <code>e</code> à la suite de l'élément courant
     *  et supprime les éléments postérieurs à cet élément courant.
     * S'il n'y a pas d'élément courant, ajoute simplement <code>e</code>
     *  comme premier élément.
     * L'élément <code>e</code> devient le nouvel élément courant.
     * @pre <pre>
     *     e != null </pre>
     * @post <pre>
     *     !isEmpty()
     *     getCurrentPosition() == 
     *                 min(old getCurrentPosition() + 1, getMaxHeight())
     *     getCurrentElement() == e
     *     getEndPosition() == getCurrentPosition()
     *     si l'historique était plein, le plus ancien élément a disparu </pre>
     */
    public void add(E e) {
    	Contract.checkCondition(e != null, "e est null");    	
    	while (iterator.hasNext()) {
    		iterator.next();
    		iterator.remove();
    	} 
    	if (history.size() == mHeight) {
    		history.remove(0);
    		iterator = history.listIterator(history.size());
    	}
    	iterator.add(e);
    }

    /**
     * Avance le curseur vers la fin de l'historique.
     * @pre <pre>
     *     getCurrentPosition() < getEndPosition() </pre>
     * @post <pre>
     *     getCurrentPosition() == old getCurrentPosition() + 1 </pre>
     */
    public void goForward() {
    	Contract.checkCondition(getCurrentPosition() < getEndPosition(), "Erreur de position");
    		iterator.next();
    }
    
    /**
     * Recule le curseur vers le début de l'historique.
     * @pre <pre>
     *     getCurrentPosition() > 0 </pre>
     * @post <pre>
     *     getCurrentPosition() == old getCurrentPosition() - 1 </pre>
     */
    public void goBackward() {
    	Contract.checkCondition(getCurrentPosition() > 0, "Erreur de position");
    		iterator.previous();
    }
}
