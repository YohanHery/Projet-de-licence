package serie02.model;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import serie02.util.FileStateTester;
import util.Contract;

public class StdSplitManager implements SplitManager{
	private File f;
	private long[] tabsplit;
	
	public StdSplitManager() { 
	f = null;
	tabsplit = null;
	}
	public StdSplitManager(File file) { 
			Contract.checkCondition(file!=null, "Ce n'est pas un fichier");
		f = file;
		tabsplit = new long[] {f.length()};
	}
	public boolean canSplit() {
		return FileStateTester.isSplittable(f);
	}
	
	public String getDescription() {
		return FileStateTester.describe(f);
	}
	
	public File getFile() {
		return f;
	}
	
	public int getMaxFragmentNb() {
		Contract.checkCondition(canSplit(), "Le fichier n'est pas fragmentable");
		long fileSize = f.length();
	    long max = Math.min(MAX_FRAGMENT_NB, fileSize);
	    return (int)max;
	}
	
	public String[] getSplitsNames() {
		Contract.checkCondition(canSplit(), "Le fichier n'est pas fragmentable");
	    String[] names = new String[tabsplit.length];
	    for (int i = 0; i < names.length; i++) {
	    	names[i] = f.getAbsolutePath() + "." + (i + 1);
	    }
	    return names;
	}	
    
    public long[] getSplitsSizes() {
    	Contract.checkCondition(canSplit(), "Le fichier n'est pas fragmentable");
    	return tabsplit.clone();
    }
   
    public void changeFor(File f) {
    	Contract.checkCondition(f!=null, "Il n'y a pas de fichier");
    	this.f = f;
    	Contract.checkCondition(canSplit(), "Le fichier n'est pas fragmentable");
    	tabsplit = new long[] {f.length()};	
    }
    
    public void close() {
        f = null;
        tabsplit = new long[0];
    }
    
    public void setSplitsNumber(int splitsNb) {
    	Contract.checkCondition(canSplit(), "Le fichier n'est pas fragmentable");
      	Contract.checkCondition(1 <= splitsNb && splitsNb <= getMaxFragmentNb(), "Le nombres de fragments n'est pas correct.");
      	long n = f.length();
        long q = n / splitsNb;
        long r = n % splitsNb;
        tabsplit = new long[splitsNb];
        for (int i = 0; i < r; ++i) {
            tabsplit[i] = q + 1;
        }
        for (int i = (int) r; i < splitsNb; ++i) {
            tabsplit[i] = q;
        }
    }
    
    public void setSplitsSizes(long size) {
    	Contract.checkCondition(canSplit(), "Le fichier n'est pas fragmentable");
      	Contract.checkCondition(1 <= size && size <= getFile().length(), "Le nombres de fragments n'est pas correct.");
      	long n = f.length();
        long q = n / size;
        long r = n % size;
        if (r > 0) {
            tabsplit = new long[(int) Math.min(q+1, getMaxFragmentNb())];
        }
        if (r == 0) {
            tabsplit = new long[(int) Math.min(q, getMaxFragmentNb())];
        }
        for (int i = 0; i < tabsplit.length -1; i++) {
            tabsplit[i] = size;
        }
        tabsplit[tabsplit.length -1] = n - (size*(tabsplit.length-1));
    }
    
    public void setSplitsSizes(long[] sizes) {
        Contract.checkCondition(canSplit(), "Le fichier n'est pas fragmentable");
        Contract.checkCondition(sizes != null && sizes.length >= 1,
                "Tableau de tailles invalide");
        for (long s : sizes) {
            Contract.checkCondition(s >= 1, "Taille de fragment invalide");
        }
        long n = f.length();
        long sum = 0;
        int k = 0;
        while (k < sizes.length && sum + sizes[k] < n && k < getMaxFragmentNb() - 1) {
            sum += sizes[k];
            k++;
        }
        int fragmentsNb = Math.min(k + 1, getMaxFragmentNb());
        tabsplit = new long[fragmentsNb];

        for (int i = 0; i < fragmentsNb - 1; i++) {
            tabsplit[i] = sizes[i];
        }
        tabsplit[fragmentsNb - 1] = n - sum;
    }

    public void split() throws IOException {
        Contract.checkCondition(canSplit(), "Le fichier n'est pas fragmentable");
        String[] names = getSplitsNames();
        InputStream in = new BufferedInputStream(new FileInputStream(f));
        try {
            for (int i = 0; i < tabsplit.length; i++) {
            	OutputStream out = new FileOutputStream(names[i]);
                try {
                    long remaining = tabsplit[i];
                   	for (int k = 0; k < remaining; ++k) {
                        int read = in.read();
                        out.write(read);
                    }
                }finally {
                	out.close();
                }
            }
        } finally {
        	in.close();
        }
    }	
}
