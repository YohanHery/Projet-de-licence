package serie08;

import java.util.Observable;

import util.Contract;

public class StdSpeedometerModel extends Observable implements SpeedometerModel  {
	private double st;
	private double mx;
	private SpeedUnit units;
	private double speed;
	private boolean engineState;
	StdSpeedometerModel(double step, double max){
		Contract.checkCondition(1 <= step && step <= max, "Step not in the range");
		st = step;
		mx = max;
		units = SpeedUnit.KMH;
		engineState = false;
	}
	@Override
	public double getMaxSpeed() {
		if (getUnit() == SpeedUnit.KMH) {
			return mx;
		} else {
			return (mx * this.getUnit().getUnitPerKm());
		}
	}

	@Override
	public double getSpeed() {
		if (getUnit() == SpeedUnit.KMH  ) {
			return speed;
		} else {
			return (speed * this.getUnit().getUnitPerKm());
		}
	}

	@Override
	public double getStep() {
		if (getUnit() == SpeedUnit.KMH ) {
			return st;
		} else {
			return (st * this.getUnit().getUnitPerKm());
		}
		
	}

	@Override
	public SpeedUnit getUnit() {
		return units;
	}

	@Override
	public boolean isOn() {
		return engineState;
	}

	@Override
	public void setUnit(SpeedUnit unit) {
		Contract.checkCondition(unit != null, "pas d'unité");
		units = unit;
		setChanged();
		notifyObservers();
	}

	@Override
	public void slowDown() {
		Contract.checkCondition(isOn(), "Le moteur est éteint");
		speed = Math.max(0, speed - st);
		setChanged();
		notifyObservers();
	}

	@Override
	public void speedUp() {
		Contract.checkCondition(isOn(), "Le moteur est éteint");
		speed = Math.min(mx, speed + st);
		setChanged();
		notifyObservers();
	}

	@Override
	public void turnOff() {
		Contract.checkCondition(isOn(), "Le moteur est déjà éteint");
		speed = 0;
		engineState = false;
		setChanged();
		notifyObservers();
	}

	@Override
	public void turnOn() {
		Contract.checkCondition(!isOn(), "Le moteur est déjà allumé");
		engineState = true;
		setChanged();
		notifyObservers();
	}

}
