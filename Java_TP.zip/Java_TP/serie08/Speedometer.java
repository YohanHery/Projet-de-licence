package serie08;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;

import serie08.SpeedometerModel.SpeedUnit;

public class Speedometer {
	private JFrame mainFrame;
	private SpeedometerModel model;
	private GraphicSpeedometer speedometer;
	private ButtonGroup bg;
	private JRadioButton[] units;
	private JButton speedUp;
	private JButton slowDown;
	private JButton onOff;
	
	public Speedometer() {
		createModel();
		createView();
		placeComponents();
		createController();
	}
	
	private void display() {
		refresh();
		mainFrame.pack();
		mainFrame.setLocationRelativeTo(null);
		mainFrame.setVisible(true);
	}

	private void createModel() {
		model = new StdSpeedometerModel(5.0,100.0);
	}

	private void createView() {
		mainFrame = new JFrame("");
		int i = 0;
		units = new JRadioButton[SpeedUnit.values().length];
		for (SpeedUnit x: SpeedUnit.values()) {
			units[i] = new JRadioButton(x.toString(), i==0);
			++i;
		}
		speedUp = new JButton("+");
		slowDown = new JButton("-");
		onOff = new JButton();
		speedometer = new GraphicSpeedometer(model);
	}

	private void placeComponents() {
		JPanel p = new JPanel(new GridLayout(0,1)); 
		{
			JPanel q = new JPanel();
			{
				JPanel r = new JPanel(new GridLayout(0,1));
				Border b = BorderFactory.createEtchedBorder();
				{
					for (JRadioButton x: units) {
						r.add(x);
					}
				}
				r.setBorder(b);
				q.add(r);
			}
			p.add(q);
			q = new JPanel();
			{
				JPanel r = new JPanel(new GridLayout(1,0));
				{
					r.add(slowDown);
					r.add(speedUp);
				}
				q.add(r);
			}
			p.add(q);
			q = new JPanel();
			{
				q.add(onOff);
			}
			p.add(q);
		}
		mainFrame.add(p,BorderLayout.WEST);
		mainFrame.add(speedometer,BorderLayout.CENTER);
	}

	private void createController() {
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		bg = new ButtonGroup();
		
		((Observable) model).addObserver(new Observer() {
			@Override
			public void update(Observable model, Object arg) {
				refresh();
			}
		});
		
		ActionListener ac = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String s = ((JRadioButton) e.getSource()).getText();
				for(SpeedUnit u : SpeedUnit.values()) {
					if(s.equals(u.toString())) {
						model.setUnit(u);
					}
				}
			}
		};
		
		for (JRadioButton b: units) {
			b.addActionListener(ac);
			bg.add(b);
		}
		
		onOff.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!model.isOn()) {
					model.turnOn();
				} else {
					model.turnOff();
				}
			}
		});
		
		speedUp.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				model.speedUp();
			}
		});
		
		slowDown.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				model.slowDown();
			}
		});
	}
	
	private void refresh() {
		speedUp.setEnabled(model.isOn());
		slowDown.setEnabled(model.isOn());
		for (JRadioButton b: units) {
			b.setEnabled(model.isOn());
		}
		speedometer.repaint();
		onOff.setText(model.isOn() ? "Turn Off" : "Turn On");
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				new Speedometer().display();
			}
		});
	}

	
}
