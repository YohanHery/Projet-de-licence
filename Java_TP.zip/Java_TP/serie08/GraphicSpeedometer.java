package serie08;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JComponent;

import util.Contract;

public class GraphicSpeedometer extends JComponent {
    // marge horizontale interne de part et d'autre du composant
    private static final int MARGIN = 40;
    // épaisseur de la ligne horizontale graduée
    private static final int THICK = 3;
    // demi-hauteur d'une graduation
    private static final int MARK = 5;
    // largeur de la base du triangle pour la tête de la flèche
    private static final int ARROW_BASE = 20;
    // épaisseur du corps de la flèche
    private static final int ARROW_THICK = 4;
    // hauteur du corps de la flèche
    private static final int ARROW_HEIGHT = 20;
    // hauteur préférée d'un GraphicSpeedometer
    private static final int PREFERRED_HEIGHT = 3 * (3 * MARK + ARROW_BASE / 2 + ARROW_HEIGHT);
    // facteur d'échelle pour l'espacement entre deux graduations
    private static final double ASPECT_RATIO = 1.25;
    // couleur bleu franc lorsque le moteur est allumé
    private static final Color BLUE = Color.BLUE;
    // couleur rouge franc lorsque le moteur est allumé
    private static final Color RED = Color.RED;
    // couleur bleu grisé lorsque le moteur est éteint
    private static final Color GRAYED_BLUE = new Color(0, 0, 255, 50);
    // couleur rouge grisé lorsque le moteur est éteint
    private static final Color GRAYED_RED = new Color(255, 0, 0, 50);
    // les vitesses affichées sont celles, entre 0 et model.getMaxSpeed(), qui sont les multiples de SPLIT_SIZE
    private static final int SPLIT_SIZE = 10;
    
    private SpeedometerModel model;
    
    public GraphicSpeedometer(SpeedometerModel model) {
    	Contract.checkCondition(model != null);
    	this.model = model;
    	Dimension d = new Dimension();
    	d.setSize(ASPECT_RATIO * ARROW_BASE 
    			* (model.getMaxSpeed() / SPLIT_SIZE) 
    			+ 2 * MARGIN, 
    			PREFERRED_HEIGHT);
    	setPreferredSize(d);
    	((Observable) model).addObserver(new Observer() {
			@Override
			public void update(Observable o, Object arg) {
				repaint();
			}
			
		});
    }
    
    public SpeedometerModel getModel() {
    	return model;
    }
    
    @Override
	protected void paintComponent(Graphics g) {
    	super.paintComponent(g);
    	
    	int h = getHeight()/3;
    	int w = getWidth() - 2 * MARGIN;
        double xA = MARGIN + (w * model.getSpeed()) / model.getMaxSpeed() - ARROW_BASE / 2;
        double yA = h + THICK + 2 * MARK + ARROW_BASE / 2;
        double xB = xA + ARROW_BASE/2;
        double yB = yA - ARROW_BASE/2;
        double xC = xA + ARROW_BASE;
        double yC = yA;
        double xP = xA + (ARROW_BASE - ARROW_THICK)/2;
        double yP = yA;
        g.setColor(model.isOn()? RED : GRAYED_RED);

        g.fillPolygon(new int[] {(int) xA,(int) xB,(int) xC},
        		new int[] {(int) yA,(int) yB,(int) yC}, 3);
        g.fillRect((int) xP, (int) yP, ARROW_THICK, ARROW_HEIGHT);
        
        g.setColor(model.isOn()? BLUE : GRAYED_BLUE);
        g.fillRect(MARGIN, h, w, THICK);
        for (int i = 0; i <= model.getMaxSpeed() / SPLIT_SIZE; i++) {
        	FontMetrics fm = g.getFontMetrics();
        	String s = String.valueOf(i * SPLIT_SIZE);
        	int sWidth = fm.stringWidth(s);
            double xQ = MARGIN + i * w * SPLIT_SIZE / model.getMaxSpeed() - sWidth / 2;
            double yQ = h - 2 * MARK;
            g.drawString(s, (int) xQ, (int) yQ);
            double x = MARGIN + i * w * SPLIT_SIZE / model.getMaxSpeed();
            double y1 = h + MARK + THICK;
            double y2 = y1 - (2* MARK + THICK);
            g.drawLine((int) x, (int) y1,(int) x,(int) y2);
        }
    }
}
