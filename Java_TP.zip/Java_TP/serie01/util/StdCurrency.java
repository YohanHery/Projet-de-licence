package serie01.util;

public final class StdCurrency implements Currency {
	private double rate;
	private final CurrencyId id;
	
	public StdCurrency(CurrencyId exid, double exrate) {
		if (exid == null ) {
			throw new AssertionError("Problème d'id");
		}
		if (exrate <= 0) {
			throw new AssertionError("Problème de taux de change");
		}
		this.rate = exrate;
		this.id = exid;
	}
	
    public CurrencyId getId() {
		return this.id;
	}

    public double getExchangeRate() {
    	return this.rate;
    }

    public String getIsoCode() {
    	return id.isoCode();
    }

    public String getCountry() {
    	return id.location();
    }

    public String getName() {
    	return id.denomination();
    }

    public void setExchangeRate(double r) {
    	if (r <= 0) {
    		throw new AssertionError("Le taux doit être positif !");
    	}
    	if (getId() == CurrencyId.EUR) {
    		throw new AssertionError("L'euro ne peut être changer. !");
    	}
    	rate = r;
    }
}
