package serie01.util;

import java.util.EnumMap;
import java.util.Map;

public class StdCurrencyDB implements CurrencyDB {
	private final Map<CurrencyId,Currency> cache;

	public StdCurrencyDB() {
		cache = new EnumMap<CurrencyId,Currency>(CurrencyId.class);
	}
	
	public Currency getCurrency(CurrencyId id) {
		if (id == null) {
			throw new AssertionError("L'id n'existe pas");
		}
		Currency c = cache.get(id);
		if (c == null) {
			c = new StdCurrency(id,id.rateForYear2001());
			cache.put(id, c);
		}
		return c;
	}
	
	public void sync() throws DBAccessException{	
	}
}
