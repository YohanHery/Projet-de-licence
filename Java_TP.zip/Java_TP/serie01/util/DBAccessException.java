package serie01.util;

public class DBAccessException extends Exception {
    
    public DBAccessException() {
        super();
    }
    
    public DBAccessException(String m) {
        super(m);
    }

}
