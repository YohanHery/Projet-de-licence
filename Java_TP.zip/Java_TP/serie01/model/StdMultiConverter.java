package serie01.model;

import serie01.util.Currency;
import util.Contract;

public class StdMultiConverter implements MultiConverter {

	private Currency[] cur;
	private int currencyNb;
	private double amount;
	
	public StdMultiConverter(Currency initCur, int n) {
		Contract.checkCondition(initCur != null, "initCur est null");	
		Contract.checkCondition(n>=2, "n est inférieur à 2");	
		cur = new Currency[n];
		currencyNb = n;
		amount = 0.0;
		for(int i= 0; i< currencyNb;++i) {
			cur[i] = initCur;
		}
	}
	 
    public double getAmount(int index) {
    	Contract.checkCondition(0<= index && index< getCurrencyNb(), "Mauvais index");
    	return amount * cur[index].getExchangeRate();
    }

    public Currency getCurrency(int index) {
    	Contract.checkCondition(0<= index && index< getCurrencyNb(), "Mauvais index");
    	return cur[index];
    }
    
    public int getCurrencyNb() {
    	return currencyNb;
    }
    
    public double getExchangeRate(int index1, int index2) {
    	Contract.checkCondition(0<= index1 && index1< getCurrencyNb(), "Mauvais index");
    	Contract.checkCondition(0<= index2 && index2< getCurrencyNb(), "Mauvais index");
    	return (cur[index2].getExchangeRate()/cur[index1].getExchangeRate());
    }

    public void setAmount(int index, double amount) {
    	Contract.checkCondition(0<= index && index< getCurrencyNb(), "Mauvais index");
    	Contract.checkCondition(amount >= 0.0, "Montant impossible");
    	this.amount = amount / cur[index].getExchangeRate();
    }

    public void setCurrency(int index, Currency c){
    	Contract.checkCondition(0<= index && index< getCurrencyNb(), "Mauvais index");
    	Contract.checkCondition(c != null, "Devise null");
    	this.cur[index] = c;
    }
}
