package serie05;

import util.Contract;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class StdPhoneNumber implements PhoneNumber {
	private static String CAPTURE_PATTERN = 
			SEPARATORS 
			+ "(?:" + NATIONAL_PREFIX + "|\\" + INTERNATIONAL_PREFIX  + ")?"
			+ "("+ "(?:" + SEPARATORS + "\\d){" + DIGITS_NB + "}"+")"
			+ SEPARATORS + "("+"\\d*"+")" 
			+ SEPARATORS;
	
	private String extension;
	private char[] digits;
	
	public StdPhoneNumber(String n) {
		Contract.checkCondition(n != null, "il n'y a pas de numéro");
		Contract.checkCondition(testString(n), "le numéro n'est pas valide");
		digits = new char[DIGITS_NB];
		Matcher m = Pattern.compile(CAPTURE_PATTERN).matcher(n);
		m.matches();
		String numbers = m.group(1);
		Matcher m2 = Pattern.compile("\\d").matcher(numbers);
		int i = 0;
		while(m2.find() && i < DIGITS_NB) {
			digits[i] = m2.group().charAt(0);
			i += 1;
		}
		extension = m.group(2);
	}
	@Override
	public char digit(int i) {
		Contract.checkCondition(i >= 1 && i <= DIGITS_NB);
		return digits[i-1];
	}

	@Override
	public String extension() {
		return extension;
	}

	@Override
	public String international() {
		StringBuilder sb = new StringBuilder("+33");
		for (int i = 0; i < digits.length; ++i) {
			String sep = (i == 0) ? " " : "";
			sb.append(sep).append(digits[i]);
		}
		if (extension != null && !extension.isEmpty()) {
			sb.append("~").append(extension);
		}
		return sb.toString();
	}
	
	@Override
	public String national() {
		StringBuilder sb = new StringBuilder("0");
		for (int i = 0; i < digits.length; ++i) {
			String sep = (i % 2 == 1) ? " " : "";
			sb.append(sep).append(digits[i]);
		}
		if (extension != null && !extension.isEmpty()) {
			sb.append(" (").append(extension).append(")");
		}
		return sb.toString();
	}
	
	@Override
    public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < digits.length; ++i) {
			sb.append(digits[i]);
			if (i < digits.length -1) {
				sb.append(",");
			}
		}
		if (extension != null && !extension.isEmpty()) {
			sb.append(";").append(extension());
		}
		return sb.toString();
	}
	
	private static boolean testString(String n) {
		return Pattern.compile(CAPTURE_PATTERN).matcher(n).matches();
	}
}
