package serie05;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import serie04.Civ;
import serie04.Contact;
import serie04.StdPhoneBook;
import util.Contract;

public class StdPersistentPhoneBook<C extends Contact & Comparable<C>,N extends PhoneNumber> extends StdPhoneBook<C, N> implements PersistentPhoneBook<C, N> {

	private File f;
	private DataFactory<C,N> daf;
	
	public StdPersistentPhoneBook(DataFactory<C, N> df, File file) {
		Contract.checkCondition(df!=null , "La data est vide");
		f = file;
		daf = df;
	}
	
	public StdPersistentPhoneBook(DataFactory<C, N> df) {
		Contract.checkCondition(df!=null , "La data est vide");
		f = null;
		daf = df;
	}
	
	@Override
	public File getFile() {
		return f;
	}

	@Override
	public void load() throws IOException, BadSyntaxException{
		Contract.checkCondition(getFile()!=null);
		clear();
		BufferedReader rd = new BufferedReader(new FileReader(f));
		Matcher m;
		try {
			String s = rd.readLine();
			while(s != null) {
				m = Pattern.compile(LINE_PATTERN).matcher(s);
				if (!m.matches()) {
					rd.close();
					clear();
					throw new BadSyntaxException();
				}
				String[] strTab = s.split(FSEP);
				int i = 0;
				for (String x : strTab) {
					strTab[i] = x.trim();
					i++;
				}
				String[] numStrings = strTab[3].split(NSEP);
				ArrayList<N> phoneNumbers = new ArrayList<N>();
				for (String x: numStrings) {
					phoneNumbers.add(daf.createPhoneNumber(x));
				}
				C contact = daf.createContact(Civ.values()[Integer.valueOf(strTab[0])],
						strTab[1], strTab[2]);
				if (!contains(contact)) {
					addEntry(contact,phoneNumbers);
				} else {
					for (N number: phoneNumbers) {
						addPhoneNumber(contact,number);
					}
				}
				s= rd.readLine();
			}
		}
		catch (IOException e) {
			clear();
			throw e;
		} finally {
			rd.close();
		}
	}

	@Override
	public void save() throws IOException{
		Contract.checkCondition(getFile()!=null);
		BufferedWriter wr = new BufferedWriter(new FileWriter(f));
		for (C c: contacts()) {
			StringBuffer s = new StringBuffer();
			s.append(c.getCivility().ordinal() + FSEP);
			s.append(c.getLastName() + FSEP);
			s.append(c.getFirstName() + FSEP);
			List<N> numbers = phoneNumbers(c);
			s.append(numbers.get(0).national());
			for (int i = 1; i < numbers.size(); i+=1) {
				String num = numbers.get(i).national();
				s.append(NSEP + num);
			}
			try {
				wr.write(s.toString());
				wr.newLine();
			} catch (IOException e) {
				wr.close();
				throw e;
			}
		}
		wr.close();
	}

	@Override
	public void setFile(File file) {
		Contract.checkCondition(file != null, "Il n'y a pas de fichier!");
		f = file;
	}

}
