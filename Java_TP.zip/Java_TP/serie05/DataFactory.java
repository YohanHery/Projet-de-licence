package serie05;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import serie04.Civ;
import serie04.Contact;

/**
 * Fabrique de contacts et de numéros de téléphones respectant les
 *  spécifications de constructeurs données dans les interfaces Contact et
 *  PhoneNumber.
 */
class DataFactory<C extends Contact & Comparable<C>, N extends PhoneNumber> {

    private final Class<C> contactType;
    private final Class<N> phoneNumberType;
    
    /**
     * Une fabrique pour les types contactType et phoneNumberType.
     */
    DataFactory(Class<C> contactType, Class<N> phoneNumberType) {
        this.contactType = contactType;
        this.phoneNumberType = phoneNumberType;
    }

    /**
     * Retourne une instance de C si possible, sinon lève une erreur.
     */
    C createContact(Civ civ, String lastName, String firstName) {
        String cName = contactType.getSimpleName();
        C result = null;
        try {
            Constructor<C> cons = contactType.getConstructor(Civ.class,
                    String.class, String.class);
            result = cons.newInstance(civ, lastName, firstName);
        } catch (SecurityException e) {
            throw new Error(
                    "Le type " + cName + " n'est pas accessible", e);
        } catch (NoSuchMethodException e) {
            throw new Error(
                    "Le constructeur " + cName + "(Civ, String, String)"
                    + " n'existe pas",
                    e);
        } catch (IllegalArgumentException e) {
            throw new Error(
                    "Le constructeur " + cName + "(Civ, String, String)"
                    + " n'existe pas",
                    e);
        } catch (InstantiationException e) {
            throw new Error("La classe " + cName + " n'est pas concrète", e);
        } catch (IllegalAccessException e) {
            throw new Error("La classe " + cName + " n'est pas accessible", e);
        } catch (InvocationTargetException e) {
            throw new Error("Le constructeur de " + cName + " a levé"
                    + " une exception " + e.getCause(),
                    e);
        }
        return result;
    }

    /**
     * Retourne une instance de N si possible, sinon lève une erreur.
     */
    N createPhoneNumber(String num) {
        String pName = phoneNumberType.getSimpleName();
        N result = null;
        try {
            Constructor<N> cons = phoneNumberType.getConstructor(String.class);
            result = cons.newInstance(num);
        } catch (SecurityException e) {
            throw new Error(
                    "Le type " + pName + " n'est pas accessible", e);
        } catch (NoSuchMethodException e) {
            throw new Error(
                    "Le constructeur " + pName + "(String) n'existe pas", e);
        } catch (IllegalArgumentException e) {
            throw new Error(
                    "Le constructeur " + pName + "(String) n'existe pas", e);
        } catch (InstantiationException e) {
            throw new Error("La classe " + pName + " n'est pas concrète", e);
        } catch (IllegalAccessException e) {
            throw new Error("La classe " + pName + " n'est pas accessible", e);
        } catch (InvocationTargetException e) {
            throw new Error("Le constructeur de " + pName + " a levé"
                    + " une exception " + e.getCause(),
                    e);
        }
        return result;
    }
}
