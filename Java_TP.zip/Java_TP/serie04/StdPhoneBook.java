package serie04;

import java.util.ArrayList;
import java.util.List;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.TreeMap;

import util.Contract;

public class StdPhoneBook<C extends Contact & Comparable<C>, N> implements PhoneBook<C, N> {	
	private final NavigableMap<C, List <N>> annuaire;
	
	public StdPhoneBook(){
		annuaire = new TreeMap<C, List<N>>();
	}

	@Override
    public NavigableSet<C> contacts(){
		return annuaire.navigableKeySet();
	}
    
	@Override
    public boolean contains(C p) {
    Contract.checkCondition(p!=null, "Il me faut une personne à chercher !");
    return annuaire.containsKey(p);
    }
    

	@Override
    public boolean isEmpty() {
    	return contacts().size() == 0 ;
    }
    
	@Override
	public List<N> phoneNumbers(C p) {
		Contract.checkCondition(p != null);
		return annuaire.get(p);
	}
    // COMMANDES
    
	@Override
	public void addEntry(C p, N n) {
		Contract.checkCondition(p!=null && !contains(p));
		Contract.checkCondition(n!=null);
		List<N> l = new ArrayList<N>();
		l.add(n);
		annuaire.put(p,l);
	}

    public void addEntry(C p, List<N> nums) {
    	Contract.checkCondition(p!= null && !contains(p), "La personne est déjà la ou tu n'as rien renseigné");
    	Contract.checkCondition(nums != null && nums.size() > 0, "Pas de numéro renseigné ou déjà un numéro");
    	Contract.checkCondition(check_numbers(nums));
    	List<N> pn = new ArrayList<N>();
    	for (N num : nums) {
    		if (!pn.contains(num)) {
    			pn.add(num);
    		}
    	}
    	annuaire.put(p, pn);
    }
    
    private boolean check_numbers(List<N> n) {
    	for(N num : n) {
    		if( num == null) {
    			return false;
    		}
    	}
    	return true;
    }
    
    public void addPhoneNumber(C p, N n) {
    	Contract.checkCondition(p!= null & contains(p), "La personne est null ou n'existe pas");
    	Contract.checkCondition(n!= null, "Il faut renseigner un numéro");
    	List<N> numbers = annuaire.get(p);
    	if (!numbers.contains(n)) {
    	numbers.add(n);
    	annuaire.put(p, numbers);
    	}
    }
    
	@Override
	public void clear() {
		annuaire.clear();
	}
	
    /**
     * Supprime un numéro donné pour un contact donné.
     * Si ce numéro est le seul numéro de la personne, l'entrée complète est
     *  retirée de l'annuaire.
     * Ne fait rien si le numéro n'est pas dans la liste des numéros de p.
     * @pre <pre>
     *     (p != null) && contains(p)
     *     n != null </pre>
     * @post <pre>
     *     old phoneNumbers(p).contains(n) 
     *         ==> old phoneNumbers(p).size() == 1
     *                 ==> !contains(p)
     *             old phoneNumbers(p).size() > 1
     *                 ==> Let oldSize  ::= old phoneNumbers(p).size()
     *                         oldPlace ::= old  phoneNumbers(p).indexOf(n)
     *                     phoneNumbers(p).size() == oldSize - 1
     *                     forall i, 0 <= i < oldPlace :
     *                         phoneNumbers(p).get(i).equals(
     *                             old phoneNumbers(p).get(i))
     *                     forall i, oldPlace <= i < phoneNumbers(p).size() :
     *                         phoneNumbers(p).get(i).equals(
     *                             old phoneNumbers(p).get(i + 1))
     *     old !phoneNumbers(p).contains(n)
     *         ==> phoneNumbers(p).equals(old phoneNumbers(p)) </pre>
     */
    public void deletePhoneNumber(C p, N n) {
    	Contract.checkCondition(p!=null && contains(p), "Il n'est pas là ou n'existe pas");
    	Contract.checkCondition(n!=null, "Il n'y a pas de numéro");
    	List<N> pn = phoneNumbers(p);
    	if(pn.size() == 1 && n == phoneNumbers(p).get(0)) {
    		this.removeEntry(p);
    	}else {
    		pn.remove(n);
    		annuaire.put(p, pn);
    	}
    }
    
	@Override
	public void removeEntry(C p) {
		Contract.checkCondition(p!=null);
		annuaire.remove(p);
	}
	
	
	
	
	
	
	
	
}
