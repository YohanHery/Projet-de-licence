package serie04;

import java.util.EnumSet;
import java.util.Set;
import util.Contract;

public enum Civ {
	UKN,
	MR,
	MRS,
	MS;
	
	private Set<Civ> candidates;
	private String desc;
	
	static {
		UKN.candidates = EnumSet.of(MR,MRS,MS);
		UKN.desc = "";
		MRS.candidates = EnumSet.of(MS);
		MRS.desc = "Mme";
		MS.candidates = EnumSet.of(MRS);
		MS.desc = "Mlle";
		MR.candidates = EnumSet.noneOf(Civ.class);
		MR.desc = "M.";
	}
	
	public boolean canEvolveTo(Civ candidate) {
		Contract.checkCondition(candidate!=null);
		return candidates.contains(candidate);
	}
	
	public String toString() {
		return desc;
	}
}
