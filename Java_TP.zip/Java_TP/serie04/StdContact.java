package serie04;

import util.Contract;


public class StdContact implements Contact {
	private String nom;
	private String prenom;
	private Civ civilite;
	public StdContact (String n, String p) {
		Contract.checkCondition( n != null && p != null, "Il faut un nom et un prénom à ton petit bonhomme !");
		Contract.checkCondition(!n.equals("") || !p.equals(""), "Il faut un nom et un prénom à ton petit bonhomme !");
		nom = n;
		prenom = p;
		civilite = Civ.UKN;
	}
	public StdContact (Civ c, String n, String p) {
		Contract.checkCondition( c!= null && n != null && p != null, "Il faut un nom et un prénom à ton je ne sais quoi !");
		Contract.checkCondition(!n.equals("") || !p.equals(""), "Il faut un nom et un prénom à ton je ne sais quoi !");
		nom = n;
		prenom = p;
		civilite = c;
	}
	
    public boolean equals(Object other) {
    	boolean result = false;
    	if (other instanceof Contact) {
    		StdContact x = (StdContact) other;
    		result = civilite == x.getCivility() && nom.equals(x.getLastName()) 
    				&& prenom.equals(x.getFirstName());
    	}
    	return result;
    }
    
    public Civ getCivility() {
    	return civilite;
    }
    
	@Override
	public String getFirstName() {
		return prenom;
	}

	@Override
	public String getLastName() {
		return nom;
	}

	public int hashCode() {
		int x = 17;
		x += 31 * civilite.hashCode();
		x += 31 * nom.hashCode();
		x += 31 * prenom.hashCode();
		return x;
	}
	
	public int compareTo(StdContact c) {
		if (this.equals(c)) {
			return 0;
		}
		if (c.getLastName().compareTo(nom) > 0
			|| c.getLastName().equals(nom) 
				&& c.getFirstName().compareTo(prenom) > 0
			|| c.getLastName().equals(nom) 
				&& c.getFirstName().equals(prenom) 
				&& c.getCivility().compareTo(civilite)> 0) {
			return -1;
		}
		return 1;
	}
	
	@Override
	public String toString() {
		return getCivility() + " " + getFirstName() + " " + getLastName();	
	}
	
	
	public Contact evolve(Civ civility) {
		Contract.checkCondition(civility!=null && getCivility().canEvolveTo(civility));
		return new StdContact(civility,nom,prenom);
	}
}
