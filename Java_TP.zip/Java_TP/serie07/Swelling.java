package serie07;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class Swelling {
	
	private JFrame mainFrame;
    private JButton change;
    private JButton reset;
    private JTextField factor;
    private SwellingModel model;
	
	public Swelling() {
        createModel();
        createView();
        placeComponents();
        createController();
    }
	
	private void createModel() {
		model = new StdSwellingModel();
		
	}
	
	public void display() {
		refresh();
        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
        mainFrame.setPreferredSize(new Dimension(200,200));
        Dimension d = mainFrame.getPreferredSize();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        model.setMin(d);
        model.setMax(screenSize);
        model.setCurrent(d);
    }
	
	private void createView() {
        mainFrame = new JFrame("Baudruche");
        reset = new JButton("Réinitialiser");
        change = new JButton("Modifier");
        factor = new JTextField(8);
    }
	
	 private void placeComponents() {
	        JPanel p = new JPanel();
	        {
	            p.add(new JLabel("Facteur : "));
	            p.add(factor);
	            p.add(new JLabel("%"));
	            p.add(change);
	        }
	        mainFrame.add(p,BorderLayout.NORTH);
	        p = new JPanel();
	        {
	        	p.add(reset);
	        }
	        mainFrame.add(p,BorderLayout.SOUTH);
	 }
	 
	 private void createController() {
		 mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        
		 ((Observable) model).addObserver(new Observer() {
			 @Override
	         public void update(Observable o, Object arg) {
	    		 refresh();
	         }
	     });
		 
		 change.addActionListener(new ActionListener() {
	    	 @Override
	    	 public void actionPerformed(ActionEvent e) {
	    		 try {
	    			 String res= factor.getText().trim();
					 double x = Double.parseDouble(res);
	    			 if(!model.isValidScaleFactor(x)) {
	    				 errWindow(res);
	    			 } else {
	    				 model.scaleCurrent(x);
	    			 }
	    			 factor.setText("");
	    		 } catch (NumberFormatException nfe) {
	    			 errWindow(factor.getText());
	    		 }
	         }
		 });

	     reset.addActionListener(new ActionListener() {
	    	 @Override
	    	 public void actionPerformed(ActionEvent e) {
	    		 model.setCurrent(mainFrame.getPreferredSize());
	         }
	     });
	 }
	 
	 private void refresh() {
		 mainFrame.setSize(model.current());
	 }
	 
	 private void errWindow(String s) {
		 JOptionPane.showMessageDialog(
			    	null, 
			    	"Valeur inattendue: " + s,
			    	"Erreur !",
			    	JOptionPane.ERROR_MESSAGE
			 );
	 }
	 
	 public static void main(String[] args) {
		 SwingUtilities.invokeLater(new Runnable() {
			 @Override
	         public void run() {
				 new Swelling().display();
			 }
		 });
	 }
}
