package serie07;

import java.awt.Dimension;

import util.Contract;
import java.util.Observable;


public class StdSwellingModel extends Observable implements SwellingModel {
	private Dimension min;
	private Dimension max;
	private Dimension cur;
	public StdSwellingModel() {
		min = new Dimension(0,0);
		max = new Dimension(0,0); 
		cur = new Dimension(0,0); 
	}
	@Override
	public Dimension current() {
		return new Dimension((int)cur.getWidth(),(int)cur.getHeight());
	}

	@Override
	public boolean isSurroundedBy(Dimension d) {
		Contract.checkCondition(d!=null);
		return cur.getHeight() <= d.getHeight() && 
				cur.getWidth() <= d.getWidth(); 
	}

	@Override
	public boolean isSurrounding(Dimension d) {
		Contract.checkCondition(d!=null);
		return cur.getHeight() >= d.getHeight() && 
				cur.getWidth() >= d.getWidth(); 
	}

	@Override
	public boolean isValidScaleFactor(double f) {
		if (f >= MIN_FACTOR) {
			Dimension t = new Dimension((int)(cur.getWidth() * (1 + f / 100)), (int)(cur.getHeight() * (1 + f / 100)));
			return contains(min,t) && contains(t,max);
			}
		return false;
	}

	@Override
	public Dimension max() {
		return new Dimension((int)max.getWidth(),(int)max.getHeight());
	}

	@Override
	public Dimension min() {
		return new Dimension((int)min.getWidth(),(int)min.getHeight());
	}

	@Override
	public void scaleCurrent(double f) {
		System.out.println("scaleCurrent : cur = " + cur.getWidth() + ", " + cur.getHeight() + " / min " + min.getWidth() + ", " + min.getHeight() + " / max " + max.getWidth() + ", " + max.getHeight() + ")");
		Contract.checkCondition(isValidScaleFactor(f));
		cur.setSize((cur.getWidth() * (1+f/100)),(cur.getHeight() * (1+f/100)));
		System.out.println("scaleCurrent : cur = " + cur.getWidth() + ", " + cur.getHeight() + " / min " + min.getWidth() + ", " + min.getHeight() + " / max " + max.getWidth() + ", " + max.getHeight() + ")");
		setChanged();
		notifyObservers();
	}

	@Override
	public void setCurrent(Dimension d) {
		Contract.checkCondition(d != null);
		System.out.println("setCurrent : cur = " + cur.getWidth() + ", " + cur.getHeight() + " / min " + min.getWidth() + ", " + min.getHeight() + " / max " + max.getWidth() + ", " + max.getHeight() + ")"+"/ d : "+ d.getWidth()+","+ d.getHeight());
		Contract.checkCondition(contains(min(),d) && contains(d,max()));
		cur.setSize(d.getWidth(),d.getHeight());
		setChanged();
		notifyObservers();
		System.out.println("setCurrent : cur = " + cur.getWidth() + ", " + cur.getHeight() + " / min " + min.getWidth() + ", " + min.getHeight() + " / max " + max.getWidth() + ", " + max.getHeight() + ")");
	}

	@Override
	public void setMax(Dimension d) {
		System.out.println("setMax : cur = " + cur.getWidth() + ", " + cur.getHeight() + " / min " + min.getWidth() + ", " + min.getHeight() + " / max " + max.getWidth() + ", " + max.getHeight() + ")");
		Contract.checkCondition(d != null);
		Contract.checkCondition(contains(new Dimension(0,0),d));
		if (!contains(min,d)) {
			min.setSize(d.getWidth(),d.getHeight());
		}
		if (!contains(cur,d)) {
			cur.setSize(d.getWidth(),d.getHeight());
		}
		max.setSize(d.getWidth(),d.getHeight());
		setChanged();
		notifyObservers();
		System.out.println("setMax : cur = " + cur.getWidth() + ", " + cur.getHeight() + " / min " + min.getWidth() + ", " + min.getHeight() + " / max " + max.getWidth() + ", " + max.getHeight() + ")");
	}

	@Override
	public void setMin(Dimension d) {
		System.out.println("setMin : cur = " + cur.getWidth() + ", " + cur.getHeight() + " / min " + min.getWidth() + ", " + min.getHeight() + " / max " + max.getWidth() + ", " + max.getHeight() + ")");
		Contract.checkCondition(d != null);
		Contract.checkCondition(contains(new Dimension(0,0),d));
		if (!contains(d,max)) {
			max.setSize(d.getWidth(),d.getHeight());
		}
		if (!contains(d,cur)) {
			cur.setSize(d.getWidth(),d.getHeight());
		}
		min.setSize(d.getWidth(),d.getHeight());
		setChanged();
		notifyObservers();
		System.out.println("setMin : cur = " + cur.getWidth() + ", " + cur.getHeight() + " / min " + min.getWidth() + ", " + min.getHeight() + " / max " + max.getWidth() + ", " + max.getHeight() + ")");
	}

	
	// TOOLS
	private boolean contains(Dimension d, Dimension des) {
		return d.getHeight()<= des.getHeight() && d.getWidth()<= des.getWidth();	
	}
}
