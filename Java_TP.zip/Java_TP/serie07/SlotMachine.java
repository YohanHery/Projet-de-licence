package serie07;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class SlotMachine {
	
	private JFrame mainFrame;
    private JButton rollButton;
    private JTextField letters;
    private JLabel nbCoinsUsed;
    private JLabel nbCoinsWonTotal;
    private JLabel nbCoinsWon;
    private SlotModel model;
    
    public SlotMachine() {
        createModel();
        createView();
        placeComponents();
        createController();
    }
    
    public void display() {
        refresh();
        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }
    
    private void createModel() {
    	int[] credits = new int[] {0,5,100};
        model = new StdSlotModel(credits);
    }
    
    private void createView() {
    	final int frameWidth = 275;
        final int frameHeight = 120;
        
        mainFrame = new JFrame("Slot Machine");
        mainFrame.setPreferredSize(new Dimension(frameWidth, frameHeight));
        
        rollButton = new JButton("Tentez votre chance!");
        letters = new JTextField(model.result());
        letters.setEditable(false);
        nbCoinsUsed = new JLabel(Integer.toString(model.moneyLost()));
        nbCoinsWonTotal = new JLabel(Integer.toString(model.moneyWon()));
        nbCoinsWon = new JLabel("0");
    }
    
    private void placeComponents() {
        JPanel p = new JPanel();
        {
            p.add(rollButton);
            p.add(letters);
        }
        mainFrame.add(p, BorderLayout.NORTH);
        p = new JPanel();
        { //--
    		p.add(new JLabel(" Pertes:"));
    		p.add(nbCoinsUsed);
    		p.add(new JLabel(" Gains:"));
    		p.add(nbCoinsWonTotal);
    	} //--
        mainFrame.add(p, BorderLayout.CENTER);
        p = new JPanel();
    	{ //--
    		p.add(new JLabel(" Vous venez de gagner:"));
    		p.add(nbCoinsWon);
    		
    	}//--
    	mainFrame.add(p,BorderLayout.SOUTH);
    }
    private void createController() {
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        ((Observable) model).addObserver(new Observer() {
            @Override
            public void update(Observable o, Object arg) {
                refresh();
            }
        });

        rollButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.gamble();
            }
        });
    }
    
    private void refresh() {    
    	letters.setText(""+model.result()+""); 
    	nbCoinsWonTotal.setText(""+model.moneyWon()+"");
    	nbCoinsUsed.setText(""+model.moneyLost()+"");
    	nbCoinsWon.setText(""+model.lastPayout()+"");
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SlotMachine().display();
            }
        });
    }

}
