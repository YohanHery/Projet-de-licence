package serie07;

import java.util.Observable;
import java.util.Random;

import util.Contract;
public class StdSlotModel extends Observable implements SlotModel {
	private int[] cred;
	private int monwon;
	private int monlos;
	private int lastpay;
	private String res;
	
	public StdSlotModel(int[] credits) {
		Contract.checkCondition(testCred(credits));
		cred = credits.clone();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < credits.length ; i+=1) {
			sb.append(' ');
		}
		res = sb.toString();
	}
	
	@Override
	public int credit(int n) {
		Contract.checkCondition(1 <= n && n <= size());
		return cred[n-1];
	}

	@Override
	public int lastPayout() {
		return lastpay;
	}

	@Override
	public int moneyLost() {
		return monlos;
	}

	@Override
	public int moneyWon() {
		return monwon;
	}

	@Override
	public String result() {
		return res;
	}

	@Override
	public int size() {
		return res.length();
	}

	@Override
	public void gamble() {
		monlos += 1;
		res = newResult();
		lastpay = credit(sameLettersNb());
		monwon += lastpay;
		setChanged();
        notifyObservers();
	}

	private boolean testCred(int[] credits) {
		if (credits == null || credits.length < MIN_RESULT_SIZE) {
			return false;
		}
		for (int i: credits) {
			if (i < 0) {
				return false;
			}
		}
		return true;
	}
	private String newResult() {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < cred.length ; i+=1) {
			Random r = new Random();
			int n = r.nextInt(26);
			char a ='A';
			a += n; 
			sb.append(a);
		}
		return sb.toString();
	}
	
	private int sameLettersNb() {
		int[] occ = new int[26];
		for (int i = 0; i < size() ; i+=1) {
			char a = res.charAt(i);
			occ[a - 'A'] += 1;
		}
		int max = occ[0];
		for (int i = 0; i < occ.length ; i+=1) {
			if (occ[i] > max) {
				max = occ[i];
			}
		}
		return max;
	}
}
