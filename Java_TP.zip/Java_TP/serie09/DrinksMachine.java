package serie09;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import serie06.CoinTypes;
import serie06.DrinkTypes;


public class DrinksMachine {
	
	private JFrame mainFrame;
	private StdDrinksMachineModel model;
	private JButton[] drinks;
	private JButton take;
	private JButton insert;
	private JButton cancel;
	private JLabel canGetChange;
	private JLabel credit;
	private JTextField selectedDrink;
	private JTextField moneyInsert;
	private JTextField change;
	
	public DrinksMachine() {
		createModel();
		createView();
		placeComponents();
		createController();
	}
	
	public void display() {
		refresh();
        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
	}

	private void createModel() {
		model = new StdDrinksMachineModel();
	}

	private void createView() {
		mainFrame = new JFrame("Distributeur de boissons");
		drinks = new JButton[DrinkTypes.values().length];
		for (int i= 0; i< drinks.length ; i++) {
			drinks[i] = new JButton(DrinkTypes.values()[i].toString());
		}
		insert = new JButton("Insérer");
		cancel = new JButton("Annuler");
		selectedDrink = new JTextField(12);
		selectedDrink.setEditable(false);
		change = new JTextField(3);
		change.setEditable(false);
		moneyInsert = new JTextField(3);
		take = new JButton("Prenez votre boisson et/ou votre monnaie");
		credit = new JLabel();
		canGetChange = new JLabel();
	}

	private void placeComponents() {
		JPanel p = new JPanel(new GridLayout(0,1));
		{
			JPanel q = new JPanel();
			{
				q.add(canGetChange);
			}
			p.add(q);
			q = new JPanel();
			{
				q.add(credit);
			}
			p.add(q);
		}
		mainFrame.add(p, BorderLayout.NORTH);
		p = new JPanel(new GridLayout(drinks.length,2));
		{
			for (int i = 0; i < drinks.length ; i++) {
				p.add(drinks[i]);
				p.add(new JLabel(DrinkTypes.values()[i].getPrice()
						+ " cents"));
			}
		}
		mainFrame.add(p, BorderLayout.WEST);
		p = new JPanel();
		{
			JPanel q = new JPanel(new GridLayout(2,2));
			{
				q.add(insert);
				JPanel r = new JPanel();
				{
					r.add(moneyInsert);
					r.add(new JLabel("cents"));
				}
				q.add(r);
				q.add(cancel);
			}
			p.add(q);
		}
		mainFrame.add(p,BorderLayout.EAST);
		p = new JPanel(new GridLayout(0,1));
		{
			JPanel q = new JPanel(new GridLayout(1,0));
			{
				JPanel r = new JPanel();
				{
					r.add(new JLabel("Boisson : "));
					r.add(selectedDrink);
				}
				q.add(r);
				r = new JPanel();
				{
					r.add(new JLabel("Monnaie : "));
					r.add(change);
					r.add(new JLabel("cents"));
				}
				q.add(r);
			}
			p.add(q);
			q = new JPanel();
			{
				q.add(take);
			}
			p.add(q);
		}
		mainFrame.add(p, BorderLayout.SOUTH);
	}

	private void createController() {
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		((Observable) model).addObserver(new Observer() {
			@Override
			public void update(Observable o, Object arg) {
				refresh();
			}	
		});
		
		ActionListener ac = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JButton x = (JButton) e.getSource();
				for (DrinkTypes d: DrinkTypes.values()) {
					if (x.getText().equals(d.toString())) {
						if(d.getPrice() <= model.getCreditAmount()) {
							if(model.getLastDrink() == null) {
								model.selectDrink(d);
							} else {
								errWindowDrink();
							}
						}
					}
				}
			}
		};
		
		for (JButton b: drinks) {
			b.addActionListener(ac);
		}
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String s = moneyInsert.getText().trim();
					int x = Integer.parseInt(s);
					CoinTypes c = CoinTypes.getCoinType(x);
					if (c!=null) {
						moneyInsert.setText("");
						model.insertCoin(c);
					} else {
						errWindowCoin(s);
					}
				} catch(NumberFormatException nfe) {
					errWindowCoin(moneyInsert.getText().trim());
				}
			}
			
		});
		
		cancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				model.cancelCredit();
			}
			
		});
		
		take.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				model.takeDrink();
				model.takeChange();
			}		
		});
	}
	
	private void refresh() {
		selectedDrink.setText(model.getLastDrink() == null ? "" : model.getLastDrink().toString());
		change.setText(model.getChangeAmount() == 0 ? "" : String.valueOf(model.getChangeAmount()));
		if (model.canGetChange()) {
			canGetChange.setText("Cet appareil rend la monnaie");
		} else {
			canGetChange.setText("Cet appareil ne rend pas la monnaie");
		}
		credit.setText("Vous disposez d'un crédit de " + model.getCreditAmount() + " cents");
		for (JButton x: drinks) {
			for (DrinkTypes d: DrinkTypes.values()) {
				if (x.getText().equals(d.toString())) {
					if(model.getDrinkNb(d) == 0) {
						x.setEnabled(false);
					} else {
						x.setEnabled(true);
					}
				}
			}
		}
	}
	
	private void errWindowDrink() {
		 JOptionPane.showMessageDialog(
			    	null, 
			    	"Vous avez déja sélectionné une boisson",
			    	"Erreur !",
			    	JOptionPane.ERROR_MESSAGE
			 );
	}
	
	private void errWindowCoin(String s) {
		JOptionPane.showMessageDialog(
		    	null, 
		    	"Valeur inattendue: " + s,
		    	"Erreur !",
		    	JOptionPane.ERROR_MESSAGE
		 );
	}
	
	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new DrinksMachine().display();
            }
        });
    }
}
