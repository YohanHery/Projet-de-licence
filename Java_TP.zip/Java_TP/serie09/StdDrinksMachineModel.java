package serie09;

import java.util.Observable;

import serie06.CoinTypes;
import serie06.DrinkTypes;
import serie06.DrinksMachineModel;
import serie06.MoneyAmount;
import serie06.StdMoneyAmount;
import serie06.StdStock;
import serie06.Stock;
import util.Contract;

public class StdDrinksMachineModel extends Observable implements DrinksMachineModel {

	private Stock<DrinkTypes> drinksStock;
	private MoneyAmount cashbox;
	private MoneyAmount changebox;
	private MoneyAmount creditbox;
	private DrinkTypes lastDrink;
	
	public StdDrinksMachineModel() {
		drinksStock = new StdStock<DrinkTypes>();
		for (DrinkTypes d: DrinkTypes.values()) {
			drinksStock.addElement(d, MAX_DRINK);
		}
		cashbox = new StdMoneyAmount();
		changebox = new StdMoneyAmount();
		creditbox = new StdMoneyAmount();
	}
	
	@Override
	public int getCreditAmount() {
		return creditbox.getTotalValue();
		
	}

	@Override
	public int getCashAmount() {
		return cashbox.getTotalValue();
	}

	@Override
	public int getChangeAmount() {
		return changebox.getTotalValue();
	}

	@Override
	public boolean canGetChange() {
		for (int i =1; i < 200; i++) {
			if (cashbox.computeChange(i) == null) {
				return false;
			}
		}
		
		return true;
	}
	
	@Override
	public void cancelCredit() {
		changebox.addAmount(creditbox);
		creditbox.reset();
		setChanged();
		notifyObservers();
	}

	@Override
	public void takeDrink() {
		lastDrink = null;
		setChanged();
		notifyObservers();
	}

	@Override
	public void takeChange() {
		changebox.reset();
		setChanged();
		notifyObservers();
	}

	@Override
	public void reset() {
		cashbox.reset();
		creditbox.reset();
		changebox.reset();
		lastDrink = null;
		drinksStock.reset();
	}
	@Override
	public int getDrinkNb(DrinkTypes d) {
		Contract.checkCondition(d!=null);
		return drinksStock.getNumber(d);
	}
	@Override
	public DrinkTypes getLastDrink() {
		return lastDrink;
	}
	@Override
	public int getCreditNb(CoinTypes c) {
		Contract.checkCondition(c!=null);
		return creditbox.getNumber(c);
	}
	@Override
	public int getCashNb(CoinTypes c) {
		Contract.checkCondition(c!=null);
		return cashbox.getNumber(c);
	}
	@Override
	public int getChangeNb(CoinTypes c) {
		Contract.checkCondition(c!=null);
		return changebox.getNumber(c);
	}
	@Override
	public void selectDrink(DrinkTypes d) {
		Contract.checkCondition(d != null);
		Contract.checkCondition(getDrinkNb(d) >= 1);
		Contract.checkCondition(getCreditAmount() 
				>= d.getPrice());
		Contract.checkCondition(getLastDrink() == null);
		boolean changeIsOK = canGetChange();
		drinksStock.removeElement(d);
		cashbox.addAmount(creditbox);
		if (changeIsOK) {
			MoneyAmount ma = cashbox.computeChange(getCreditAmount() - d.getPrice());
			changebox.addAmount(ma);
			cashbox.removeAmount(ma);
		}
		creditbox.reset();
		lastDrink = d;
		setChanged();
		notifyObservers();
	}
	
	@Override
	public void fillStock(DrinkTypes d, int q) {
		Contract.checkCondition(d != null);
		Contract.checkCondition(q > 0 
				&& getDrinkNb(d) + q <= MAX_DRINK);
		drinksStock.addElement(d, q);
	}
	
	@Override
	public void fillCash(CoinTypes c, int q) {
		Contract.checkCondition(c!=null);
		Contract.checkCondition(q > 0 && getCashNb(c) 
		+ getCreditNb(c) + q <= MAX_COIN);
		cashbox.addElement(c,q);
	}
	
	@Override
	public void insertCoin(CoinTypes c) {
		Contract.checkCondition(c!=null);
		if (getCashNb(c) + getCreditNb(c) == MAX_COIN) {
			changebox.addElement(c);
		} else {
			creditbox.addElement(c);
		}
		setChanged();
		notifyObservers();
	}
}
