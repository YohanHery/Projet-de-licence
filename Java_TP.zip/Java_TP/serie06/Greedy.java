package serie06;

class Greedy implements ChangeAlgorithm {
	
	private MoneyAmount actAmount;
	private MoneyAmount solution;
	private boolean solutionFound;
	
	Greedy(MoneyAmount init) {
		assert init != null;
		
		actAmount = new StdMoneyAmount();
		actAmount.addAmount(init);
	}

	@Override
	public MoneyAmount getCash() {
		MoneyAmount result = new StdMoneyAmount();
		result.addAmount(actAmount);
		return result;
	}

	@Override
	public MoneyAmount getChange() {
		assert solutionFound();
		MoneyAmount result = new StdMoneyAmount();
		result.addAmount(solution);
		return result;
	}

	@Override
	public boolean solutionFound() {
		return solutionFound;
	}

	@Override
	public void computeChange(int amount) {
		assert amount > 0;
		
		solution = new StdMoneyAmount();
		for (int i = CoinTypes.values().length -1;
				i>=0 && amount>0;
				i-=1) {
			CoinTypes c = CoinTypes.values()[i];
			int x = actAmount.getNumber(c);
			if (x > 0) {
				int p = actAmount.getValue(c);
				int q = Math.min(x, amount/p);
				amount -= q * c.getFaceValue();
				if (q>0) {
					solution.addElement(c, q);
				}
			}
		}
		solutionFound = (amount == 0);
	}

}
