package serie06;

public enum CoinTypes {
	ONE(1), 
	TWO(2), 
	FIVE(5), 
	TEN(10), 
	TWENTY(20), 
	FIFTY(50), 
	ONE_HUNDRED(100),
	TWO_HUNDRED(200);

	public static CoinTypes getCoinType(int i) {
		for (CoinTypes c : CoinTypes.values()) {
			if ( i == c.getFaceValue()) {
				return c;
			}
		}
		return null;
	}
	
	private int faceValue;
	
	CoinTypes(int v){
		faceValue = v;
	}
	
	public int getFaceValue() {
		return faceValue;
	}
	
	public String toString() {
		return String.valueOf(faceValue) + (this == ONE ? " ct" : " cts");
	}
}
