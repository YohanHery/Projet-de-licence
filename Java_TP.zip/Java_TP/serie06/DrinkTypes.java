package serie06;

public enum DrinkTypes {
	COFFEE(30),
	CHOCOLATE(45),
	ORANGE_JUICE(110),
	TEQUILA(350);
	
	private int price;
	
	DrinkTypes(int p){
		price = p;
	}
	
	public int getPrice() {
		return price;
	}
	public String toString() {
		return name().replace('_', ' ').toLowerCase();
	}
}
