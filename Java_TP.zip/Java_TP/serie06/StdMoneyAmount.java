package serie06;

import util.Contract;

public class StdMoneyAmount extends StdStock<CoinTypes> implements MoneyAmount {

	@Override
	public int getValue(CoinTypes c) {
		Contract.checkCondition(c != null, "Ce type de monnaie n'existe pas");
		return getNumber(c) * c.getFaceValue();
	}

	@Override
	public int getTotalValue() {
		int s = 0;
		for (CoinTypes c: CoinTypes.values()) {
			s += getNumber(c) * c.getFaceValue();
		}
		return s;
	}

	@Override
	public void addAmount(MoneyAmount amount) {
		Contract.checkCondition(amount != null, "Pas de montant");
		for (CoinTypes c: CoinTypes.values()){
			int s = amount.getNumber(c);
			if (s > 0) {
				addElement(c, s);
			}
		}
	}

	@Override
	public MoneyAmount computeChange(int s) {
		Contract.checkCondition(s>0);
		ChangeAlgorithm algo = new BackTrack(this);
		algo.computeChange(s);
		if (algo.solutionFound()) {
			return algo.getChange();
		}
		return null;
	}

	@Override
	public void removeAmount(MoneyAmount amount) {
		Contract.checkCondition(testAmount(amount));
		for (CoinTypes c: CoinTypes.values()) {
			if (amount.getNumber(c) > 0) {
				removeElement(c, amount.getNumber(c));
			}
		}
	}

	private boolean testAmount(MoneyAmount amount) {
		if (amount == null) {
			return false;
		}
		boolean result = true;
		for (CoinTypes c: CoinTypes.values()) {
			if (getNumber(c) < amount.getNumber(c)) {
				result = false;
			}
		}	
		return result;
	}
}
