package serie06;

public class BackTrack implements ChangeAlgorithm {
	
	private MoneyAmount actAmount;
	private MoneyAmount solution;
	private boolean solutionFound;
	
	BackTrack (MoneyAmount init) {
		assert init != null;
		
		actAmount = new StdMoneyAmount();
		actAmount.addAmount(init);
	}

	@Override
	public MoneyAmount getCash() {
		MoneyAmount result = new StdMoneyAmount();
		result.addAmount(actAmount);
		return result;
	}

	@Override
	public MoneyAmount getChange() {
		assert solutionFound();
		MoneyAmount result = new StdMoneyAmount();
		result.addAmount(solution);
		return result;
	}

	@Override
	public boolean solutionFound() {
		return solutionFound;
	}

	@Override
	public void computeChange(int amount) {
		solution = new StdMoneyAmount();
		solutionFound = computeChangeAux(amount,CoinTypes.values().length - 1);
	}
	
	private boolean computeChangeAux(int amount, int i) {
		if (amount == 0) {
			return true;
		}
		if (i < 0) {
			return false;
		}
		CoinTypes coin = CoinTypes.values()[i];
		int p = coin.getFaceValue();
		for (int q =  Math.min(actAmount.getNumber(coin), 
				amount/p); q >= 0; q-=1) {
			if (computeChangeAux(amount-q*p, i-1)) {
				if ( q> 0) {
					solution.addElement(coin, q);
				}
				return true;
			}
		}
		return false;
	}
}
