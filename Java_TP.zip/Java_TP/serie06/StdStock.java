package serie06;

import java.util.Map;

import util.Contract;

import java.util.HashMap;

public class StdStock<E> implements Stock<E> {

	public Map<E, Integer> map;
	
	public StdStock(){
		map = new HashMap<E, Integer>();
	}
	
	@Override
	public int getNumber(E e) {
		Contract.checkCondition(e != null,"Le type e n'est pas valide" );
		return map.containsKey(e)? map.get(e) : 0;
	}

	@Override
	public int getTotalNumber() {
		int s = 0;
		for (int p: map.values()) {
			s += p;
		}
		return s;
	}

	@Override
	public void addElement(E e) {
		Contract.checkCondition(e != null, "Le type e n'est pas valide");
		int n = getNumber(e);
		if (n == 0) {
			map.put(e, 1);
		} else {
			map.put(e, n + 1);
		}
	}

	@Override
	public void addElement(E e, int qty) {
		Contract.checkCondition(e != null, "Le type e n'est pas valide");
		Contract.checkCondition(qty > 0, "Il me faut du stock Roger");
		int n = getNumber(e);
		if (n == 0) {
			map.put(e, qty);
		} else {
			map.put(e, qty + n);
		}
	}

	@Override
	public void removeElement(E e) {
		Contract.checkCondition(e != null, "Le type e n'est pas valide");
		Contract.checkCondition(getNumber(e) >= 1, "Il me faut des produits Bernard");
		int n = getNumber(e);
		if (n == 1) {
			map.remove(e);
		} else {
			map.put(e, n - 1);
		}
	}

	@Override
	public void removeElement(E e, int qty) {
		Contract.checkCondition(e != null, "Le type e n'est pas valide");
		Contract.checkCondition(qty > 0, "Il me faut des produits Bernard");
		Contract.checkCondition(getNumber(e) >= qty, "Il me faut du stock Roger");
		int n = getNumber(e);
		if (n == qty) {
			map.remove(e);
		} else {
			map.put(e, n - qty);
		}
	}

	@Override
	public void reset() {
		map.clear();
	}
}
