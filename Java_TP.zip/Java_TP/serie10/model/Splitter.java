package serie10.model;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import serie02.model.SplitManager;
import serie10.model.StdSplitManager.Change;
import serie10.model.StdSplitManager;

public class Splitter {
	private static final String FILE_SIZE_DESC = "Taille totale du fichier : ";
	private static final String FRAG_DESC= "Description des fragments du fichier : ";
	private static final String FRAG_SIZE_DESC = "Taille moyenne d'un fragment : ";
	private static final String UNDEF_DESC = "non défini";
	
	private JFrame mainFrame;
	private SplitManager model;
	private JTextField filename;
	private JTextField fragsize;
	private JComboBox<Integer> fragNb;
	private JButton split;
	private JButton browse;
	private JTextArea desc;
	
	public Splitter() {
        createModel();
        createView();
        placeComponents();
        createController();
    }
	
	 public void display() {
	        refresh(Change.FILE_CHANGE,true);
	        mainFrame.pack();
	        mainFrame.setLocationRelativeTo(null);
	        mainFrame.setVisible(true);
	 }

	private void createModel() {
		model = new StdSplitManager();		
	}

	private void createView() {
		mainFrame = new JFrame("Fragmenteur de fichiers");
		filename = new JTextField(24);
		fragNb = new JComboBox<Integer>();
		fragsize = new JTextField(3);
		split = new JButton("Fragmenter !");
		browse = new JButton("Parcourir...");
		desc = new JTextArea();
	}

	private void placeComponents() {
		JPanel p = new JPanel();
		{
			p.add(new JLabel("Fichier à fragmenter :"));
			p.add(filename);
			p.add(browse);
		}
		mainFrame.add(p,BorderLayout.NORTH);
		mainFrame.add(new JScrollPane(desc),BorderLayout.CENTER);
		p = new JPanel(new GridLayout(2,1));
		{
			JPanel q = new JPanel(new BorderLayout());
			{
				JPanel r = new JPanel(new GridLayout(2,2));
				{
					JPanel s = new JPanel(new FlowLayout(FlowLayout.RIGHT));
					{
						s.add(new JLabel("Nb. fragments :"));
					}
					r.add(s);
					s = new JPanel(new FlowLayout(FlowLayout.LEFT));
					{
						s.add(fragNb);
					}
					r.add(s);
					s = new JPanel(new FlowLayout(FlowLayout.RIGHT));
					{
						s.add(new JLabel("Taille des fragments* :"));
					}
					r.add(s);
					s = new JPanel(new FlowLayout(FlowLayout.LEFT));
					{
						s.add(fragsize);
						s.add(new JLabel("octets"));
					}
					r.add(s);
				}
				q.add(r,BorderLayout.SOUTH);
			}
			p.add(q);
			q = new JPanel();
			{
				q.add(split);
			}
			p.add(q);
		}
		mainFrame.add(p,BorderLayout.WEST);
		mainFrame.add(new JLabel("(*)Il s'agit de la taille de chaque"
				+ " fragment à un octet près, sauf peut-être"
				+ " pour le dernier fragment."), BorderLayout.SOUTH);
		
	}

	private void createController() {
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		((Observable) model).addObserver(new Observer() {
            @Override
            public void update(Observable o, Object arg) {
                refresh(arg,false);
            }
        });
		
		browse.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser x = new JFileChooser();
				if (x.showDialog(null, "Confirmer") == JFileChooser.APPROVE_OPTION) {
					File f = x.getSelectedFile();
					if (f!=null) {
						model.changeFor(f);
					}
				}
			}
			
		});
		
		filename.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String s = filename.getText();
				if (s == null) {
					return;
				}
				File f = new File(s);

				model.changeFor(f);
			}
			
		});
		
		fragsize.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					long x = Long.parseLong(fragsize.getText().trim());
					if(x >= Math.max(SplitManager.MIN_FRAGMENT_SIZE,
							Math.ceil(model.getFile().length() / model.getMaxFragmentNb() ))) {
						model.setSplitsSizes(x);
					} else {
						errWindowFragsize();
					}
				} catch (NumberFormatException nfe) {
					errWindowFragsizeExc();
				}
			}
			
		});
		
		fragNb.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				model.setSplitsNumber((Integer) fragNb.getSelectedItem());
			}	
		});
		
		split.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					model.split();
					succWindowSplit();
				} catch (IOException e1) {
					errWindowSplitExc();
				}
			}
		});
	}
	
	private void refresh(Object arg, boolean firstLaunch) {
		if (arg == null) {
			return;
		}
		switch((Change) arg) {
			case FILE_CHANGE:
				filename.setText(model.getFile() == null? "" : model.getFile().getAbsolutePath());
				fragNb.setEnabled(model.canSplit());
				fragsize.setEnabled(model.canSplit());
				desc.setEnabled(model.canSplit());
				split.setEnabled(model.canSplit());
				descRefresh();
				if (model.canSplit()) {
					Integer[] numbers = new Integer[model.getMaxFragmentNb()];
					for (int i = 0; i< model.getMaxFragmentNb();i++ ) {
						numbers[i] = i+1;
					}
					fragNb.setModel( new DefaultComboBoxModel<Integer>(numbers));
					fragsize.setText(
							String.valueOf(model.getSplitsSizes()[0]));
					ActionListener[] ac = fragNb.getActionListeners();
					for(ActionListener a : ac) {
						fragNb.removeActionListener(a);
					}
					fragNb.setSelectedIndex(model.getSplitsSizes().length - 1);
					for(ActionListener a : ac) {
						fragNb.addActionListener(a);
					}
				} else if (!firstLaunch) {
					fragNb.setModel(new DefaultComboBoxModel<Integer>());
					fragsize.setText("");
					filename.setText("Ceci n'est pas le nom d'un fichier valide.");
					errWindowFile();
				}
				break;
				
			case CONFIG_CHANGE:
				fragsize.setText(
						String.valueOf(model.getSplitsSizes()[0]));
				descRefresh();
				ActionListener[] ac = fragNb.getActionListeners();
				for(ActionListener a : ac) {
					fragNb.removeActionListener(a);
				}
				fragNb.setSelectedIndex(model.getSplitsSizes().length - 1);
				for(ActionListener a : ac) {
					fragNb.addActionListener(a);
				}
		}	///home/yohan/start-xampp.sh.1
	}
	
	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Splitter().display();
            }
        });
    }
	
	private long moyenne(long[] sizes) {
		long m = 0;
		for(long x: sizes) {
			m += x;
		}
		m/= sizes.length;
		return m;
	}
	
	private void descRefresh() {
		desc.setText(FILE_SIZE_DESC + (model.canSplit()? 
				model.getFile().length() : UNDEF_DESC) + '\n' );
		desc.append("\n");
		desc.append(FRAG_DESC + '\n');
		if (model.canSplit()) {
			for (int i = 0; i < model.getSplitsSizes().length;i+=1) {
				desc.append( '\t' + model.getSplitsNames()[i] + " : "
					+ model.getSplitsSizes()[i] + " octets.");
				desc.append("\n");
			}
		} else {
			desc.append("\t" + UNDEF_DESC + "\n");
		}
		desc.append("\n" + FRAG_SIZE_DESC + (model.canSplit()? 
				moyenne(model.getSplitsSizes())  + " octets." : UNDEF_DESC));
	}
	
	private void errWindowFile() {
		 JOptionPane.showMessageDialog(
			    	null, 
			    	"Nom de fichier non valide",
			    	"Erreur !",
			    	JOptionPane.ERROR_MESSAGE
			 );
	 }
	
	private void errWindowFragsize() {
		 JOptionPane.showMessageDialog(
			    	null, 
			    	"Nombre non valide",
			    	"Erreur !",
			    	JOptionPane.ERROR_MESSAGE
			 );
	 }
	
	private void errWindowFragsizeExc() {
		 JOptionPane.showMessageDialog(
			    	null, 
			    	"Erreur de saisie",
			    	"Erreur !",
			    	JOptionPane.ERROR_MESSAGE
			 );
	 }
	
	private void errWindowSplitExc() {
		 JOptionPane.showMessageDialog(
			    	null, 
			    	"Fragmentation échouée",
			    	"Erreur !",
			    	JOptionPane.ERROR_MESSAGE
			 );
	 }
	
	private void succWindowSplit() {
		 JOptionPane.showMessageDialog(
			    	null, 
			    	"Fragmentation réussie!",
			    	"Succès !",
			    	JOptionPane.INFORMATION_MESSAGE
			 );
	 }
}
