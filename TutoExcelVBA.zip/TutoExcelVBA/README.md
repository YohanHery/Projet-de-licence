Voici le tutoriel Excel en VBA 

Suivre ces étapes:

1\) Ouvrir le fichier VBA

2\) Si des valeurs, tableaux ou graphiques sont présents sur la page 

&nbsp;             - Ctrl+A -> Suppr puis cliquer sur le graphique et supprimer le

3\) Appuyer sur Alt+F8 simultanément

&nbsp;	- Un onglet nommé Macro va alors s'ouvrir

4\) Sélectionner LancerTuto si il n'est pas déjà présélectionné et cliquer sur Exécuter

5\) Lire le tuto et suivre le courant vous emporter

