open FCC

(* Compléter ce fichier avec les éléments du fichier DPLL.ml du TP 4 nécessaires pour le projet,
   en plus des définitions ci-dessous. *)

(** Simplifie la forme clausale fcc en considérant que le littéral lu est vrai *)
let simplif_fcc fcc l =
  FormeClausale.map
    (function c -> Clause.remove (neg_lit l) c)
    (FormeClausale.filter (function c -> not (Clause.mem l c)) fcc)

(** Renvoie la liste des listes de couples (atome, Booléen) suffisants pour que la formule soit vraie,
    selon l'algorithme DPLL. *)
let dpll_all_sat (fcc : forme_clausale) : (string * bool) list list =
  let rec aux fcc =
    if FormeClausale.is_empty fcc then [ [] ]
      (* Aucune clause, donc satisfaisable trivialement *)
    else if FormeClausale.exists Clause.is_empty fcc then []
      (* Insatisfaisable car contient une clause vide *)
    else
      let cl = FormeClausale.choose fcc in
      let lit = Clause.choose cl in
      let true_branch = aux (simplif_fcc fcc lit) in
      let false_branch = aux (simplif_fcc fcc (neg_lit lit)) in
      List.map (fun sol -> (snd lit, true) :: sol) true_branch
      @ List.map (fun sol -> (snd lit, false) :: sol) false_branch
  in
  aux fcc

(** Applique l'algorithme DPLL pour déterminer si une fcc est satisfaisable. *)
let dpll_sat f =
  let rec aux f =
    match FormeClausale.min_elt_opt f with
    | None -> true
    | Some c -> (
        match Clause.min_elt_opt c with
        | None -> false
        | Some l -> aux (simplif_fcc f l) || aux (simplif_fcc f (neg_lit l)))
  in
  aux f

(** Applique l'algorithme DPLL pour déterminer si une fcc est satisfaisable. 
    Utilise la propagation unitaire. *)
let dpll_sat_unit_prop (fcc : forme_clausale) : bool =
  let rec aux fcc =
    let unit_propagate fcc =
      let single_literal_clause =
        FormeClausale.find_first_opt (fun cl -> Clause.cardinal cl = 1) fcc
      in
      match single_literal_clause with
      | Some cl -> Some (Clause.choose cl)
      | None -> None
    in
    match unit_propagate fcc with
    | Some lit -> aux (simplif_fcc fcc lit)
    | None ->
        dpll_sat
          fcc (* Retombe sur DPLL simple si aucune propagation n'est possible *)
  in
  aux fcc
