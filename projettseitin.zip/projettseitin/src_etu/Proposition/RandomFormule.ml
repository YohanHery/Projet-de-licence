open Formule

(** random_form atoms k renvoie une formule pseudo-aléatoire
   avec k opérateurs et des atomes de la liste atoms, liste
   supposée non vide. Les opérateurs sont Top, Bot, Non, Et
   Ou et Imp. La formule générée ne doit pas contenir
   d'opérateurs d'équivalence. *)

(** Donne un atome aléatoire parmi l'alphabet *)
let random_atome (l : string list) = List.nth l (Random.int (List.length l))

let random_form (l : string list) : int -> formule =
 fun n ->
  let rec rand m =
    match m with
    | 0 -> Atome (random_atome l)
    | 1 -> (
        let randt = Random.int 3 in
        match randt with
        | 0 -> if random_atome [ "⊤"; "⊥" ] == "⊤" then Top else Bot
        | 1 -> Non (Atome (random_atome l))
        | _ -> (
            match Random.int 3 with
            | 0 -> Et (Atome (random_atome l), Atome (random_atome l))
            | 1 -> Ou (Atome (random_atome l), Atome (random_atome l))
            | _ -> Imp (Atome (random_atome l), Atome (random_atome l))))
    | _ -> (
        let k = Random.int m in
        match Random.int 4 with
        | 0 -> Non (rand (m - 1))
        | 1 -> Et (rand k, rand (m - k - 1))
        | 2 -> Ou (rand k, rand (m - k - 1))
        | _ -> Imp (rand k, rand (m - k - 1)))
  in
  rand n
