open Formule
open Tseitin
open Quine
open RandomFormule
open DPLL
open FCC

(** Vérifie si f contient une équivalence *)
let contain_equiv (f : formule) : bool =
  let rec aux f =
    match f with
    | Equiv (_, _) -> true
    | Imp (f1, f2) | Ou (f1, f2) | Et (f1, f2) -> aux f1 || aux f2
    | Non f1 -> aux f1
    | Atome _ | Bot | Top -> false
  in
  aux f

let test_equisat_quine (f : formule) : unit =
  if contain_equiv f then failwith "La formule ne doit pas contenir de Equiv\n"
  else (
    print_string ("\nF = " ^ string_of_formule f ^ "\n");
    let tf = tseitin f in
    print_string ("\nF = " ^ string_of_formule tf ^ "\n");
    let b = quine_sat f in
    Printf.printf "\nSatisfaisabilité de fcc: %b\n" b;
    let b' = quine_sat tf in
    Printf.printf "\nSatisfaisabilité de fcc': %b\n" b';
    Printf.printf "Equivalence de: %b\n" (b = b'))

let test_equisat_quine' (l : string list) (n : int) : unit =
  let f = random_form l n in
  test_equisat_quine f

(* Vérifie si tout les éléments de list sont vrai *)
let true_list list =
  let rec aux list =
    match list with [] -> true | t :: q -> if t == true then aux q else false
  in
  aux list

(* Crée une interprétation de list *)
let create_inter list : interpretation = fun s -> List.assoc s list

let test_equisat_dpll (f : formule) : unit =
  if contain_equiv f then failwith "La formule ne doit pas contenir de Equiv"
  else (
    print_string ("F = " ^ string_of_formule f ^ "\n");
    let tf = tseitin f in
    print_string ("T(F) = " ^ string_of_formule tf ^ "\n");
    let ts = dpll_all_sat (formule_to_fcc f) in
    let ts' = dpll_all_sat (formule_to_fcc tf) in
    let is = List.map create_inter ts in
    let is' = List.map create_inter ts' in
    let is_ext = List.map (fun i -> extension_inter i f) is in
    let is'_res = List.map (fun i -> restrict_inter i) is' in
    let b1 = true_list (List.map (fun i -> eval i tf) is_ext) in
    Printf.printf "%b" b1;
    let b2 = true_list (List.map (fun i -> eval i f) is'_res) in
    Printf.printf "%b" b2)

let test_equisat_dpll' (l : string list) (n : int) : unit =
  let f = random_form l n in
  test_equisat_dpll f
