#require "zarith";;

(* Ouverture des modules Z et Q du module Zarith *)
open Z;;
open Q;;

(* Transformation des chaînes de caractères en valeurs de type Q.t *)
let q1 = Q.of_string "123456789987654321/5678900987654";;
let q2 = Q.of_string "-67831300097/236543209890003";;

(* Addition des deux valeurs de type Q.t *)
let q_sum = Q.add q1 q2;;

(* Conversion du résultat de l'addition en chaîne de caractères *)
let result_string = Q.to_string q_sum;;

(* Affichage du résultat *)
print_endline result_string;;
