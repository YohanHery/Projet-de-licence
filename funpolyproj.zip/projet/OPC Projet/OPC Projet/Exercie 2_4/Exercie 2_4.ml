#require "zarith";;
open Zarith;;

(* Définition du type r_gauss *)
type r_gauss =
  | Complexe of Q.t * Q.t  (* Représente un nombre rationnel de Gauss p + qi *)
  | Indefini ;;              (* Représente une valeur indéfinie *)

  exception Indefinie;;

  (* Extraction de la partie réelle *)
  let partie_reelle = function
    | Complexe (re, _) -> re
    | Indefini -> raise Indefinie;;
  
  (* Extraction de la partie imaginaire *)
  let partie_imaginaire = function
    | Complexe (_, im) -> im
    | Indefini -> raise Indefinie;;
  

(* Fonction pour tester si un nombre de Gauss est égal à zéro *)
let est_zero = function
  | Complexe (re, im) -> Q.equal re Q.zero && Q.equal im Q.zero
  | Indefini -> false;;

(* Fonction pour tester l'égalité de deux nombres de Gauss *)
let egalite a b =
  match (a, b) with
  | (Complexe (p1, q1), Complexe (p2, q2)) -> Q.equal p1 p2 && Q.equal q1 q2
  | (Indefini, Indefini) -> true
  | _ -> false;;

(* Fonction pour ajouter deux nombres de Gauss *)
let additionner a b =
  match (a, b) with
  | (Complexe (p1, q1), Complexe (p2, q2)) -> Complexe (Q.add p1 p2, Q.add q1 q2)
  | _ -> raise Indefinie;;

(* Fonction pour multiplier deux nombres de Gauss *)
let multiplier a b =
  match (a, b) with
  | (Complexe (p1, q1), Complexe (p2, q2)) ->
      let re = Q.sub (Q.mul p1 p2) (Q.mul q1 q2) in
      let im = Q.add (Q.mul p1 q2) (Q.mul q1 p2) in
      Complexe (re, im)
  | _ -> raise Indefinie;;

(* Fonction pour obtenir l'opposé d'un nombre de Gauss *)
let oppose = function
  | Complexe (re, im) -> Complexe (Q.neg re, Q.neg im)
  | Indefini -> raise Indefinie;;

  exception Division_par_zero;;
(* Fonction pour obtenir l'inverse d'un nombre de Gauss *)
let inverse = function
  | Complexe (re, im) ->if  not (est_zero (Complexe (re, im))) then
      let denom = Q.add (Q.mul re re) (Q.mul im im) in
      let re_inv = Q.div re denom in
      let im_inv = Q.div (Q.neg im) denom in
      Complexe (re_inv, im_inv)
  else raise Division_par_zero
  | _ -> Indefini;;

(* Exemple d'utilisation *)
let r1 = Complexe (Q.of_string "1/2", Q.of_string "1/3");;
let r2 = Complexe (Q.of_string "-1/5", Q.of_string "2/7");;
let r3 = Complexe (Q.of_string "0", Q.of_string "2/7");;
let r4 = Indefini;;

let re_r1 = partie_reele r1;;
let re_r3 = partie_reele r3;;
let re_r4 = partie_reele r4;;
let im_r2 = partie_imaginaire r2;;
let zero_r1 = est_zero r1;;
let egalite_r1_r2 = egalite r1 r2;;
let somme = additionner r1 r2;;
let produit = multiplier r1 r2;;
let oppose_r1 = oppose r1;;
let inverse_r2 = inverse r2;;

(* Affichage des résultats *)
print_endline ("Partie réelle de r1 : " ^ Q.to_string re_r1);;
print_endline ("Partie réelle de r4 : " ^ Q.to_string re_r4);;
print_endline ("Partie imaginaire de r2 : " ^ Q.to_string im_r2);;
print_endline ("Est-ce que r1 est zéro ? " ^ string_of_bool zero_r1);;
print_endline ("Est-ce que r1 est égal à r2 ? " ^ string_of_bool egalite_r1_r2);;

