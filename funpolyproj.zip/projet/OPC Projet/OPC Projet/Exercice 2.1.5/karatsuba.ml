#require "zarith"

type r_gauss = 
  | Complexe of Q.t * Q.t
  | Indefini

type poly_qi = (int * r_gauss) list

let multiplier c1 c2 =
  match (c1, c2) with
  | (Complexe (a1, b1), Complexe (a2, b2)) -> 
    Complexe (Q.(add (mul a1 a2) (mul b1 b2)), Q.(add (mul a1 b2) (mul b1 a2)))
  | _ -> Indefini

let ajouter c1 c2 =
  match (c1, c2) with
  | (Complexe (a1, b1), Complexe (a2, b2)) -> Complexe (Q.add a1 a2, Q.add b1 b2)
  | _ -> Indefini

let add_poly_qi p1 p2 =
  let rec add p1 p2 acc = 
    match (p1, p2) with
    | [], [] -> List.rev acc
    | (d1, c1) :: t1, (d2, c2) :: t2 when d1 = d2 -> 
      add t1 t2 ((d1, ajouter c1 c2) :: acc)
    | (d1, c1) :: t1, (d2, _) :: _ when d1 < d2 -> 
      add t1 p2 ((d1, c1) :: acc)
    | (d1, _) :: _, (d2, c2) :: t2 when d2 < d1 -> 
      add p1 t2 ((d2, c2) :: acc)
    | [], _ -> List.rev_append acc p2
    | _, [] -> List.rev_append acc p1
  in add p1 p2 []

let rec split_at n lst =
  if n <= 0 then ([], lst)
  else match lst with
    | [] -> ([], [])
    | x :: xs -> 
      let (l1, l2) = split_at (n - 1) xs in
      (x :: l1, l2)

let rec karatsuba p1 p2 =
  if List.length p1 = 0 || List.length p2 = 0 then []
  else if List.length p1 = 1 then
    List.map (fun (deg2, c2) -> (deg2 + fst (List.hd p1), multiplier (snd (List.hd p1)) c2)) p2
  else if List.length p2 = 1 then
    List.map (fun (deg1, c1) -> (deg1 + fst (List.hd p2), multiplier c1 (snd (List.hd p2)))) p1
  else if List.length p1 < 2 || List.length p2 < 2 then
    (* Multiplier chaque élément de p1 avec chaque élément de p2 *)
    List.concat (List.map (fun (deg1, c1) -> List.map (fun (deg2, c2) -> (deg1 + deg2, multiplier c1 c2)) p2) p1)
  else
    let m = min (List.length p1 / 2) (List.length p2 / 2) in
    let (p1_lo, p1_hi) = split_at m p1 in
    let (p2_lo, p2_hi) = split_at m p2 in
    let z0 = karatsuba p1_lo p2_lo in
    let z1 = karatsuba (add_poly_qi p1_lo p1_hi) (add_poly_qi p2_lo p2_hi) in
    let z2 = karatsuba p1_hi p2_hi in
    let z1 = add_poly_qi z1 (add_poly_qi z0 z2) in
    let z1 = List.map (fun (deg, c) -> (deg + m, c)) z1 in
    let z2 = List.map (fun (deg, c) -> (deg + 2 * m, c)) z2 in
    add_poly_qi z0 (add_poly_qi z1 z2)

(* Tester karatsuba avec les polynômes a et b *)
let a = [(3, Complexe (Q.of_int 1, Q.of_int 2)); (1, Complexe (Q.of_int 3, Q.of_int 4))];;
let b = [(2, Complexe (Q.of_int 2, Q.of_int 1)); (0, Complexe (Q.of_int 1, Q.zero))];;

let result = karatsuba a b;;

(* Afficher le résultat *)
let string_of_r_gauss = function
  | Complexe (a, b) -> Printf.sprintf "(%s + %si)" (Q.to_string a) (Q.to_string b)
  | Indefini -> "Indefini"

let string_of_poly_qi poly =
  poly
  |> List.map (fun (deg, coeff) -> Printf.sprintf "%d: %s" deg (string_of_r_gauss coeff))
  |> String.concat ", "

let () = print_endline (string_of_poly_qi result)
