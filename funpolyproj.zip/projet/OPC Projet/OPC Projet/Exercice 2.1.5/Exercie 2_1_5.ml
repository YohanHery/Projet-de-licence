#require "zarith";;

(* Types pour représenter les polynômes dans Q(i)[X] *)
type r_gauss =
  | Complexe of Q.t * Q.t
  | Indefini;;

type poly_qi = (int * r_gauss) list;;



exception Indefinie;;

(* Extraction de la partie réelle *)
let partie_reelle = function
  | Complexe (re, _) -> re
  | Indefini -> raise Indefinie;;

(* Extraction de la partie imaginaire *)
let partie_imaginaire = function
  | Complexe (_, im) -> im
  | Indefini -> raise Indefinie;;


(* Fonction pour tester si un nombre de Gauss est égal à zéro *)
let est_zero = function
| Complexe (re, im) -> Q.equal re Q.zero && Q.equal im Q.zero
| Indefini -> false;;

(* Fonction pour tester l'égalité de deux nombres de Gauss *)
let egalite a b =
match (a, b) with
| (Complexe (p1, q1), Complexe (p2, q2)) -> Q.equal p1 p2 && Q.equal q1 q2
| (Indefini, Indefini) -> true
| _ -> false;;

(* Fonction pour ajouter deux nombres de Gauss *)
let additionner a b =
match (a, b) with
| (Complexe (p1, q1), Complexe (p2, q2)) -> Complexe (Q.add p1 p2, Q.add q1 q2)
| _ -> raise Indefinie;;

(* Fonction pour multiplier deux nombres de Gauss *)
let multiplier a b =
match (a, b) with
| (Complexe (p1, q1), Complexe (p2, q2)) ->
    let re = Q.sub (Q.mul p1 p2) (Q.mul q1 q2) in
    let im = Q.add (Q.mul p1 q2) (Q.mul q1 p2) in
    Complexe (re, im)
| _ -> raise Indefinie;;

(* Fonction pour obtenir la division de deux nombres de Gauss *)
let div_gauss (a: r_gauss) (b: r_gauss) : r_gauss =
  match (a, b) with
  | (Complexe (p1, q1), Complexe (p2, q2)) ->
      let denom = Q.add (Q.mul p2 p2) (Q.mul q2 q2) in
      if denom = Q.zero then
        raise (Failure "Division by zero")
      else
        let re = Q.div (Q.add (Q.mul p1 p2) (Q.mul q1 q2)) denom in
        let im = Q.div (Q.sub (Q.mul q1 p2) (Q.mul p1 q2)) denom in
        Complexe (re, im)
  | _ -> raise Indefinie;;


(* Fonction pour obtenir l'opposé d'un nombre de Gauss *)
let oppose = function
| Complexe (re, im) -> Complexe (Q.neg re, Q.neg im)
| Indefini -> raise Indefinie;;

exception Division_par_zero;;
(* Fonction pour obtenir l'inverse d'un nombre de Gauss *)
let inverse = function
| Complexe (re, im) ->if  not (est_zero (Complexe (re, im))) then
    let denom = Q.add (Q.mul re re) (Q.mul im im) in
    let re_inv = Q.div re denom in
    let im_inv = Q.div (Q.neg im) denom in
    Complexe (re_inv, im_inv)
else raise Division_par_zero
| _ -> Indefini;;


(* soustraire *)
let sub_gauss (a : r_gauss) (b : r_gauss) : r_gauss = match (a, b) with
  | Complexe (re1, im1), Complexe (re2, im2) -> Complexe (Q.sub re1 re2, Q.sub im1 im2)
  | Indefini, _ | _, Indefini -> Indefini;;

  let rec sub_poly_qi p1 p2 =
    match (p1, p2) with
    | [], [] -> []
    | [], _ -> List.map (fun (deg, c) -> (deg, oppose c)) p2
    | _, [] -> p1
    | (deg1, c1) :: rest1, (deg2, c2) :: rest2 ->
      if deg1 = deg2 then
        let diff = sub_gauss c1 c2 in
        if diff = Complexe (Q.zero, Q.zero) then
          sub_poly_qi rest1 rest2
        else
          (deg1, diff) :: sub_poly_qi rest1 rest2
      else if deg1 < deg2 then
        (deg1, c1) :: sub_poly_qi rest1 p2
      else
        (deg2, oppose c2) :: sub_poly_qi p1 rest2;;

(* Fonction d'addition de deux polynômes dans Q(i)[X] *)

let rec add_poly_qi p1 p2 =
  match (p1, p2) with
  | [], [] -> []
  | [], _ -> p2
  | _, [] -> p1
  | (deg1, c1) :: rest1, (deg2, c2) :: rest2 ->
    if deg1 = deg2 then
      let sum = additionner c1 c2 in
      if sum = Complexe (Q.zero, Q.zero) then
        add_poly_qi rest1 rest2
      else
        (deg1, sum) :: add_poly_qi rest1 rest2
    else if deg1 < deg2 then
      (deg1, c1) :: add_poly_qi rest1 p2
    else
      (deg2, c2) :: add_poly_qi p1 rest2;;

  (* Fonction de karatsuba et fonction auxiliaire si besion *)
  let rec split_at n lst =
    if n <= 0 then ([], lst)
    else match lst with
      | [] -> ([], [])
      | x :: xs -> 
        let (l1, l2) = split_at (n - 1) xs in
        (x :: l1, l2);;

    let rec karatsuba p1 p2 =
      if List.length p1 = 0 || List.length p2 = 0 then []
      else if List.length p1 = 1 then
        List.map (fun (deg2, c2) -> (deg2 + fst (List.hd p1), multiplier (snd (List.hd p1)) c2)) p2
      else if List.length p2 = 1 then
        List.map (fun (deg1, c1) -> (deg1 + fst (List.hd p2), multiplier c1 (snd (List.hd p2)))) p1
      else
        let m = min (List.length p1 / 2) (List.length p2 / 2) in
        let (p1_lo, p1_hi) = split_at m p1 in
        let (p2_lo, p2_hi) = split_at m p2 in
        let z0 = karatsuba p1_lo p2_lo in
        let z1 = karatsuba (add_poly_qi p1_lo p1_hi) (add_poly_qi p2_lo p2_hi) in
        let z2 = karatsuba p1_hi p2_hi in
        let z1 = add_poly_qi z1 (add_poly_qi z0 z2) in
        let z1 = List.map (fun (deg, c) -> (deg + m, c)) z1 in
        let z2 = List.map (fun (deg, c) -> (deg + 2 * m, c)) z2 in
        add_poly_qi z0 (add_poly_qi z1 z2);;

        (* kartsuba nouvelle version *)
        let multXn (p: poly_qi) (n: int) : poly_qi =
          List.map (fun (deg, coef) -> (deg + n, coef)) p;;


          let cut (p: poly_qi) (k: int) : poly_qi * poly_qi =
            let rec aux p acc0 acc1 =
              match p with
              | [] -> (List.rev acc0, List.rev acc1)
              | (deg, coef) :: rest ->
                if deg < k then
                  aux rest ((deg, coef) :: acc0) acc1
                else
                  aux rest acc0 ((deg - k, coef) :: acc1)
            in
            aux p [] [];;

            let choisir_coupure (deg_p: int) (deg_q: int) : int =
              min deg_p deg_q;;

              let degre (p: poly_qi) : int =
                match p with
                | [] -> -1  (* convention pour un polynôme nul *)
                | _ -> List.fold_left (fun acc (deg, _) -> max acc deg) 0 p;;


                let div_gauss ((a, b): int * r_gauss) ((c, d): int * r_gauss) : r_gauss =
                match b, d with
                | Complexe (x1, y1), Complexe (x2, y2) ->
                  let denom = Q.(x2 * x2 + y2 * y2) in
                  if denom = Q.zero then Indefini (* Si le dénominateur est nul, retourner Indéfini *)
                  else
                    let num1 = Q.(x1 * x2 + y1 * y2) in
                    let num2 = Q.(y1 * x2 - x1 * y2) in
                    Complexe (Q.(num1 / denom), Q.(num2 / denom))
                | _, _ -> Indefini (* Indéfini si l'un des nombres n'est pas un complexe *)
              ;;

  let rec div_naive (p: poly_qi) (q: poly_qi) : poly_qi =
    if degre q > degre p then [(0, Indefini)] (* Si le degré de q est supérieur à celui de p, le résultat est zéro *)
    else
      let leading_term_q = List.hd q in
      let degre_diff = degre p - degre q in
      let leading_term_p = List.hd p in
      let coeff_quotient = div_gauss leading_term_p leading_term_q in
      let quotient_term = (degre_diff, coeff_quotient) in
      let q_times_quotient = mul_poly_qi q [quotient_term] in
      let rest = sub_poly_qi p q_times_quotient in
      if rest = [(0, Indefini)] then [quotient_term]
      else
        let quotient_rest = div_naive rest q in
        add_poly_qi [quotient_term] quotient_rest;;

let rec mult_naive (p1: poly_qi) (p2: poly_qi) : poly_qi =
  match p1 with
  | [] -> []
  | (d, c)::q ->
    let k = multXn (multCoeff p2 c) d in add_poly_qi k (mult_naive q p2);;

let multCoeff (p: poly_qi) (c: r_gauss) : poly_qi =
  List.map (fun (d, r) -> (d, multiplier r c)) p
;;

            let rec karatsuba (p: poly_qi) (q: poly_qi) (k0: int) : poly_qi =
              let k = (choisir_coupure (degre p) (degre q)) * 2 in
              if k < k0 then mult_naive p q else
              let (a0, a1) = cut p (k / 2) in
              let (b0, b1) = cut q (k / 2) in
              let c0 = karatsuba a0 b0 k0 in
              let c2 = karatsuba a1 b1 k0 in
              let u = karatsuba (add_poly_qi a0 a1) (add_poly_qi b0 b1) k0 in
              let c1 = sub_poly_qi (sub_poly_qi u c0) c2 in
              add_poly_qi c0 (add_poly_qi (multXn c1 (k / 2)) (multXn c2 k));;

(* Division *)
let mul_poly_qi p1 p2 =
  let mul_term (deg1, c1) (deg2, c2) = (deg1 + deg2, multiplier c1 c2) in
  let rec mul_aux p1 p2 acc = match p1, p2 with
    | [], _ | _, [] -> acc
    | term1 :: rest1, _ ->
      let prod = List.map (mul_term term1) p2 in
      mul_aux rest1 p2 (add_poly_qi acc prod)
  in
  mul_aux p1 p2 [];;

(* Fonction division *)

let inversion_newton (r : poly_qi) (m : int) : poly_qi =
  let rec inversion_aux r_n i =
    if i > m then r_n
    else
      let term1 = sub_poly_qi [(0, Complexe (Q.one, Q.zero))] (mul_poly_qi r r_n) in
      let term2 = mul_poly_qi term1 r_n in
      let r_n_updated = add_poly_qi r_n term2 in
      inversion_aux r_n_updated (i + 1)
  in
  inversion_aux [(0, Complexe (Q.one, Q.zero))] 0;;

let div_euclidienne_newton (a : poly_qi) (b : poly_qi) : poly_qi * poly_qi =
    let deg_a = List.fold_left (fun acc (d, _) -> max acc d) 0 a in
    let deg_b = List.fold_left (fun acc (d, _) -> max acc d) 0 b in
    if deg_b = 0 then failwith "Division by zero polynomial"
    else
      let inv_b = inversion_newton b deg_a in
      let q = mul_poly_qi a inv_b in
      let q_trimmed = List.filter (fun (d, _) -> d <= (deg_a - deg_b)) q in
      let r = sub_poly_qi a (mul_poly_qi q_trimmed b) in
      let r_trimmed = List.filter (fun (d, _) -> d < deg_b) r in
      (q_trimmed, r_trimmed);;


      (* Test *)
let string_of_r_gauss = function
  | Complexe (a, b) -> Printf.sprintf "(%s + %si)" (Q.to_string a) (Q.to_string b)
  | Indefini -> "Indefini"

let string_of_poly_qi poly =
  poly
  |> List.map (fun (deg, coeff) -> Printf.sprintf "%d: %s" deg (string_of_r_gauss coeff))
  |> String.concat ", "

let a = [(2, Complexe (Q.of_int 1, Q.of_int 0)); (1, Complexe ((Q.of_string "5/7"),(Q.of_string "2/3")));(0, Complexe ((Q.of_string "1/3"),(Q.of_string "3/8")))];;
let b = [(1, Complexe (Q.of_int 1, Q.of_int 0)) ;(0, Complexe ((Q.of_string "5/8"),(Q.of_string "1/4")))];;

(* TEST KARATSUBA *)
let result = karatsuba a b 1 in
print_endline (string_of_poly_qi result);;

(* TEST ADDITION *)
let result = add_poly_qi a b in
print_endline (string_of_poly_qi result);;

(* TEST SOUSTRACTION *)
let result = sub_poly_qi a b in
print_endline (string_of_poly_qi result);;

(* TEST DIVISION *)
let (quot, r) = div_euclidienne_newton a a in
print_endline (string_of_poly_qi quot);;
