(* Types pour représenter les polynômes dans Q(i)[X] *)
module Q = struct
  type t = int  (* Remplacer ceci par la vraie définition du type rationnel *)
  let add a b = a + b  (* Exemple d'addition, à remplacer par la vraie addition de Q.t *)
  let mul a b = a * b  (* Exemple de multiplication, à remplacer par la vraie multiplication de Q.t *)
end

type r_gauss = 
  | Complexe of Q.t * Q.t
  | Indefini

type poly_qi = (int * r_gauss) list

(* Fonction pour multiplier deux coefficients r_gauss *)
let multiplier c1 c2 =
  match (c1, c2) with
  | (Complexe (a1, b1), Complexe (a2, b2)) -> 
    Complexe (Q.add (Q.mul a1 a2) (Q.mul b1 b2), Q.add (Q.mul a1 b2) (Q.mul b1 a2))
  | _ -> Indefini

(* Fonction pour additionner deux polynômes *)
let add_poly_qi p1 p2 =
  let rec add p1 p2 acc = 
    match (p1, p2) with
    | [], [] -> List.rev acc
    | (d1, c1) :: t1, (d2, c2) :: t2 when d1 = d2 -> 
      add t1 t2 ((d1, multiplier c1 c2) :: acc)
    | (d1, c1) :: t1, _ when d1 < List.hd p2 |> fst -> 
      add t1 p2 ((d1, c1) :: acc)
    | _, (d2, c2) :: t2 when d2 < List.hd p1 |> fst -> 
      add p1 t2 ((d2, c2) :: acc)
    | _ -> failwith "Unexpected pattern"
  in add p1 p2 []

(* Fonction pour diviser une liste en deux à la position n *)
let rec split_at n lst =
  if n <= 0 then ([], lst)
  else match lst with
    | [] -> ([], [])
    | x :: xs -> 
      let (l1, l2) = split_at (n - 1) xs in
      (x :: l1, l2)

(* Algorithme de Karatsuba pour multiplier deux polynômes *)
let rec karatsuba p1 p2 =
  if List.length p1 = 0 || List.length p2 == 0 then []
  else if List.length p1 == 1 then
    List.map (fun (deg2, c2) -> (deg2 + fst (List.hd p1), multiplier (snd (List.hd p1)) c2)) p2
  else if List.length p2 == 1 then
    List.map (fun (deg1, c1) -> (deg1 + fst (List.hd p2), multiplier c1 (snd (List.hd p2)))) p1
  else
    let m = min (List.length p1 / 2) (List.length p2 / 2) in
    let (p1_lo, p1_hi) = split_at m p1 in
    let (p2_lo, p2_hi) = split_at m p2 in
    let z0 = karatsuba p1_lo p2_lo in
    let z1 = karatsuba (add_poly_qi p1_lo p1_hi) (add_poly_qi p2_lo p2_hi) in
    let z2 = karatsuba p1_hi p2_hi in
    let z1 = add_poly_qi z1 (add_poly_qi z0 z2) in
    let z1 = List.map (fun (deg, c) -> (deg + m, c)) z1 in
    let z2 = List.map (fun (deg, c) -> (deg + 2 * m, c)) z2 in
    add_poly_qi z0 (add_poly_qi z1 z2)
