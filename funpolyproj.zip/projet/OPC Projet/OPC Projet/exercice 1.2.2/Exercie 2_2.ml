#require "zarith";;
open Q;;

(* Définition du type r_gauss *)
type r_gauss =
  |Complexe of Q.t * Q.t  (* Représente un nombre rationnel de Gauss p + qi *)
  |Indefini   ;;            (* Représente une valeur indéfinie *)

(* Fonction pour ajouter deux rationnels de Gauss *)
let ajouter a b =
  match (a, b) with
  | (Complexe (p1, q1), Complexe (p2, q2)) -> Complexe (Q.add p1 p2, Q.add q1 q2)
  | _ -> Indefini;;

(* Fonction pour multiplier deux rationnels de Gauss *)
let multiplier a b =
  match (a, b) with
  | (Complexe (p1, q1), Complexe (p2, q2)) ->
      let re = Q.sub (Q.mul p1 p2) (Q.mul q1 q2) in
      let im = Q.add (Q.mul p1 q2) (Q.mul q1 p2) in
      Complexe (re, im)
  | _ -> Indefini;;

(* Fonction pour diviser deux rationnels de Gauss *)
let diviser a b =
  match (a, b) with
  | (Complexe (_, _), Complexe (p2, q2)) when Q.equal p2 Q.zero && Q.equal q2 Q.zero -> Indefini
  | (Complexe (p1, q1), Complexe (p2, q2)) ->
      let denom = Q.add (Q.mul p2 p2) (Q.mul q2 q2) in
      let re = Q.div (Q.add (Q.mul p1 p2) (Q.mul q1 q2)) denom in
      let im = Q.div (Q.sub (Q.mul q1 p2) (Q.mul p1 q2)) denom in
      Complexe (re, im)
  | _ -> Indefini;;

(* Exemple d'utilisation *)
let r1 = Complexe (Q.of_string "123456789987654321/5678900987654", Q.of_string "1/3");;
let r2 = Complexe (Q.of_string "-67831300097/236543209890003", Q.of_string "2/5");;

let somme = ajouter r1 r2;;
let produit = multiplier r1 r2;;
let quotient = diviser r1 r2;;
let quotient_indefini = diviser r1 (Complexe (Q.zero, Q.zero));;

(* Affichage des résultats *)
let afficher_r_gauss = function
  | Complexe (p, q) -> Printf.printf "Complexe (%s, %s)\n" (Q.to_string p) (Q.to_string q)
  | Indefini -> Printf.printf "Indefini\n";;

afficher_r_gauss somme;;
afficher_r_gauss produit;;
afficher_r_gauss quotient;;
afficher_r_gauss quotient_indefini;;
