#require "zarith";;

open Z;;
open Q;;
(* Types pour représenter les polynômes dans Q(i)[X] *)
type poly_qi = (Q.t * Q.t) list;;

(* Fonction d'addition de deux polynômes dans Q(i)[X] *)
let add_poly_qi p1 p2 =
  let rec add_aux acc = function
    | [], [] -> List.rev acc
    | (a1, b1) :: ps1, (a2, b2) :: ps2 ->
        let sum_a = Q.add a1 a2 in
        let sum_b = Q.add b1 b2 in
        add_aux ((sum_a, sum_b) :: acc) (ps1, ps2)
    | _ -> failwith "Incompatible polynomial lengths"
  in
  add_aux [] (p1, p2);;

(* Fonction de soustraction de deux polynômes dans Q(i)[X] *)
let sub_poly_qi p1 p2 =
  let neg_poly_qi p =
    List.map (fun (a, b) -> (Q.neg a, Q.neg b)) p
  in
  add_poly_qi p1 (neg_poly_qi p2);;

(* Fonction de multiplication par X^n d'un polynôme dans Q(i)[X] *)
let rec multXn_qi p n =
  if n <= zero then p
  else multXn_qi ((Q.zero, Q.zero) :: p) (n - one);;

(* Fonction pour déterminer le degré d'un polynôme *)
let degre_poly (p: poly_qi) = of_int (List.length p) - one;;

(* Fonction de multiplication naïve de deux polynômes dans Q(i)[X] *)
let mult_naive_qi p1 p2 =
  let mult_coeff (a1, b1) (a2, b2) =
    (Q.sub (Q.mul a1 a2) (Q.mul b1 b2),
     Q.add (Q.mul a1 b2) (Q.mul b1 a2))
  in
  let rec mult_aux acc = function
    | [] -> acc
    | (a, b) :: ps -> mult_aux (add_poly_qi (List.map (mult_coeff (a, b)) p2) acc) ps
  in
  mult_aux [] p1;;

(* Fonction pour choisir le point de coupure pour la méthode de Karatsuba *)
let choisir_coupure n m = max n m / (of_int 2);;

(* Fonction récursive pour la méthode de Karatsuba *)

let rec karatsuba_aux (p: poly_qi) (q: poly_qi) k0 =
  let rec cut (p: poly_qi) (k: int) = 
    let rec take n acc = function
      | [] -> List.rev acc, []
      | x :: xs when n > zero -> take (n - one) (x :: acc) xs
      | xs -> List.rev acc, xs
    in
    take (of_int k) [] p
  in
  let mult_naive_qi = mult_naive_qi in
  let add_qi = add_poly_qi in
  let sub_qi = sub_poly_qi in
  let multXn_qi = multXn_qi in
  let rec karatsuba_aux (p: poly_qi) (q: poly_qi) k0 =
    let k = (choisir_coupure (degre_poly p) (degre_poly q)) * (of_int 2) in
    if k < k0 then mult_naive_qi p q else
      let a0, a1 = cut p (to_int (k/(of_int 2))) in
      let b0, b1 = cut q (to_int (k/(of_int 2))) in
      let c0 = karatsuba_aux a0 b0 k0 in
      let c2 = karatsuba_aux a1 b1 k0 in
      let u = karatsuba_aux (add_qi a0 a1) (add_qi b0 b1) k0 in
      let c1 = sub_qi (sub_qi u c0) c2 in
      add_qi c0 (add_qi (multXn_qi c1 ((k/(of_int 2)))) (multXn_qi c2 k))
  in
  karatsuba_aux p q k0




(* Tests pour les fonctions d'addition et de soustraction *)
let test_add_sub () =
  let p1 = [(Q.of_int 1, Q.of_int 2); (Q.of_int 3, Q.of_int 4)] in
  let p2 = [(Q.of_int 5, Q.of_int 6); (Q.of_int 7, Q.of_int 8)] in
  let sum = add_poly_qi p1 p2 in
  let diff = sub_poly_qi p1 p2 in
  (* Affichage des résultats *)
  Printf.printf "Sum: %s\n" (String.concat " + " (List.map (fun (a, b) -> Printf.sprintf "(%s, %s)" (Q.to_string a) (Q.to_string b)) sum));
  Printf.printf "Difference: %s\n" (String.concat " - " (List.map (fun (a, b) -> Printf.sprintf "(%s, %s)" (Q.to_string a) (Q.to_string b)) diff));;

(* Test pour la multiplication par X^n *)
let test_multXn () =
  let p = [(Q.of_int 1, Q.of_int 2); (Q.of_int 3, Q.of_int 4)] in
  let n = 2 in
  let result = multXn_qi p (of_int n) in
  (* Affichage du résultat *)
  Printf.printf "After multiplying by X^%d: %s\n" n (String.concat " + " (List.map (fun (a, b) -> Printf.sprintf "(%s, %s)" (Q.to_string a) (Q.to_string b)) result));;

(* Test pour la méthode de Karatsuba *)
let test_karatsuba () =
  let p = [(Q.of_int 1, Q.of_int 2); (Q.of_int 3, Q.of_int 4)] in
  let q = [(Q.of_int 5, Q.of_int 6); (Q.of_int 7, Q.of_int 8)] in
  let k0 = 1 in
  let result = karatsuba_aux p q (of_int k0) in
  (* Affichage du résultat *)
  Printf.printf "Result of Karatsuba multiplication: %s\n" (String.concat " + " (List.map (fun (a, b) -> Printf.sprintf "(%s, %s)" (Q.to_string a) (Q.to_string b)) result));;

(* Exécuter les tests *)
let () =
  test_add_sub ();
  test_multXn ();
  test_karatsuba ()

(* Division euclidienne de deux polynômes *)


(* Fonction pour calculer le degré d'un polynôme *)
let degre_poly_qi poly =
  match poly with
  | [] -> -1  (* Polynôme nul *)
  | coeffs -> to_int ((of_int (List.length coeffs)) - one);;

(* Fonction pour obtenir le coefficient d'un polynôme à un certain degré *)
let coeff_poly_qi (poly:poly_qi) degree =
  match List.nth poly degree with
  | (a, b) -> b
  | _ -> Q.zero  ;;(* Coefficient nul pour les degrés absents *)

(* Fonction pour ajouter deux polynômes *)
let additionner_poly_qi poly1 poly2 =
  let add_coeffs (a1, b1) (a2, b2) =
    (Q.add a1 a2, Q.add b1 b2)
  in
  let rec add_aux acc poly1 poly2 =
    match poly1, poly2 with
    | [], [] -> acc
    | [], p | p, [] -> acc @ p
    | (a1, b1) :: rest1, (a2, b2) :: rest2 ->
        add_aux ((add_coeffs (a1, b1) (a2, b2)) :: acc) rest1 rest2
  in
  List.rev (add_aux [] poly1 poly2);;

(* Fonction pour soustraire deux polynômes *)
let soustraire_poly_qi poly1 poly2 =
  let negate_coeff (a, b) = (Q.neg a, Q.neg b) in
  additionner_poly_qi poly1 (List.map negate_coeff poly2);;

(* Fonction pour multiplier un polynôme par un monôme (x^n) *)
let multXn_poly_qi poly n =
  let rec mult_aux acc = function
    | 0 -> acc
    | n -> mult_aux ((Q.zero, Q.zero) :: acc) (to_int ((of_int n) - one))
  in
  mult_aux poly n;;

 (* Fonction pour multiplier un polynôme par un coefficient scalaire *)
let multCoeff_poly_qi poly coeff =
  List.map (fun (a, b) -> (Q.mul a coeff, Q.mul b coeff)) poly;;


exception Division_par_le_polynome_nul;;
(* Division naïve de deux polynômes dans Q(i)[X] *)
let rec div_naive_qi p1 p2 : poly_qi * poly_qi =
  if  est_polynome_vide p2 then
    raise Division_par_le_polynome_nul
  else
    let d1 = degre_poly_qi p1 and d2 = degre_poly_qi p2 in
    if (of_int d2) > (of_int d1) then
      ([], p1)
    else
      let c1 = coeff_poly_qi p1 d1 and c2 = coeff_poly_qi p2 d2 in
      let q1 = [(Q.div c1 c2, Q.div c1 c2)] in
      let m = multXn_poly_qi p2 (to_int ((of_int d1) - (of_int d2))) in
      let r1 = soustraire_poly_qi p1 (multCoeff_poly_qi m (Q.div c1 c2)) in
      let q2, r2 = div_naive_qi r1 p2 in
      (q2 @ q1, r2);;








  (* Calcul du pgcd de deux polynômes *)
(* Vérifier si un polynôme est vide *)

let est_polynome_vide p =
  match p with
  | [] -> true
  | [(a, b)] when Q.equal a Q.zero && Q.equal b Q.zero -> true
  | _ -> false;;


(* Définir le type pour les polynômes à coefficients dans Q(i) *)
type poly_qi = (Q.t * Q.t) list;;

(* Fonction pour multiplier un polynôme par un scalaire *)
let mult_scal_poly_qi scalar poly =
  List.map (fun (a, b) -> (Q.mul scalar a, Q.mul scalar b)) poly;;

(* Fonction pour soustraire deux polynômes *)
let soustraire_poly_qi p1 p2 =
  let opp_p2 = List.map (fun (a, b) -> (Q.neg a, Q.neg b)) p2 in
  additionner_poly_qi p1 opp_p2;;

(* Division naïve des polynômes dans Q(i)[X] *)
type poly_qi = (Q.t * Q.t) list;;

(* Fonction pour soustraire deux polynômes *)
let soustraire_poly_qi p1 p2 =
  let opp_p2 = List.map (fun (a, b) -> (Q.neg a, Q.neg b)) p2 in
  additionner_poly_qi p1 opp_p2;;

(* Fonction pour multiplier un polynôme par un monôme *)
let mult_mono_poly_qi (a, b) p =
  List.map (fun (c, d) -> (Q.sub (Q.mul a c) (Q.mul b d), Q.add (Q.mul a d) (Q.mul b c))) p;;


  let monomial_quotient (a1, b1) (a2, b2) =
    let norm2 (x, y) = Q.add (Q.mul x x) (Q.mul y y) in
    let conj (x, y) = (x, Q.neg y) in
    let a2_conj = conj (a2, b2) in
    let den = norm2 (a2, b2) in
    (Q.div (Q.mul a1 (fst a2_conj)) den, Q.div (Q.mul b1 (snd a2_conj)) den);;
  

(* Fonction de division naive pour les polynômes dans Q(i)[X] *)
exception Division_par_le_polynome_nul

let rec div_naive_qi p1 p2 =
  if est_polynome_vide p2 then raise Division_par_le_polynome_nul
  else
    let rec aux r d =
      if est_polynome_vide r || (snd (List.hd r)) < (snd (List.hd d)) then ([], r)
      else
        let c1, c2 = List.hd r, List.hd d in
        let q = monomial_quotient c1 c2 in
        let q_poly = [(q)] in
        let r' = soustraire_poly_qi r (mult_mono_poly_qi q d) in
        let (q', r'') = aux r' d in
        (q_poly @ q', r'')
    in
    aux p1 p2;;


 (* Fonction pour déterminer le degré d'un polynôme *)
let degre_poly (p: poly_qi) = of_int (List.length p) - one;;
   
    let rec div_naive_qi a b = 
      if est_polynome_vide b then raise Division_par_le_polynome_nul
      else
        let d1 = degre_poly a and d2 = degre_poly b in
        if d2 > d1 then ([], a)
        else 
          let c1 = List.hd a and c2 = List.hd b in
          let q = mult_mono_poly_qi c1 c2 b in
          let r = sub_poly_qi a q in
          let (q', r') = div_naive_qi r b in
          (add_poly_qi q q', r');;
    

(* Algorithme d'Euclide étendu pour les polynômes dans Q(i)[X] *)
let euclide_etendu_qi a b =
  let rec aux r1 r2 u1 u2 v1 v2 =
    if est_polynome_vide r2 then (u1, v1, r1)
    else
      let q, r = div_naive_qi r1 r2 in
      let q_mono = List.hd q in  (* Assumes q is a non-empty list *)
      aux r2 r 
          (soustraire_poly_qi u1 (mult_mono_poly_qi q_mono u2)) u1
          (soustraire_poly_qi v1 (mult_mono_poly_qi q_mono v2)) v1
  in
  aux a b [(Q.one, Q.zero)] [(Q.zero, Q.zero)] [(Q.zero, Q.zero)] [(Q.one, Q.zero)];;




  let mult_poly_qi p1 p2 =
    let mult_coeff (a1, b1) (a2, b2) =
      (Q.sub (Q.mul a1 a2) (Q.mul b1 b2), Q.add (Q.mul a1 b2) (Q.mul b1 a2))
    in
    let rec mult_aux acc = function
      | [] -> acc
      | (a, b) :: ps ->
        let term = List.map (mult_coeff (a, b)) p2 in
        mult_aux (add_poly_qi term acc) ps
    in
    mult_aux [] p1;;
  



    let verifier_euclide_etendu a b =
      let alpha, beta, p = euclide_etendu_qi a b in
      let left_side = add_poly_qi (mult_poly_qi alpha a) (mult_poly_qi beta b) in
      (left_side, p);;
    
  
(* Fonction pour convertir un polynôme en chaîne de caractères pour affichage *)
let string_of_poly_qi poly =
  let term_to_string (a, b) =
    Printf.sprintf "(%s + %si)" (Q.to_string a) (Q.to_string b)
  in
  String.concat " + " (List.map term_to_string poly);;

(* Exemple de polynômes dans Q(i)[X] *)
let a = [(Q.of_int 1, Q.of_int 2); (Q.of_int 3, Q.of_int 4)];;
let b = [(Q.of_int 5, Q.of_int 6); (Q.of_int 7, Q.of_int 8)];;

let rec compare_poly_qi p1 p2 =
  match p1, p2 with
  | [], [] -> true
  | (a1, b1)::t1, (a2, b2)::t2 -> 
    Q.equal a1 a2 && Q.equal b1 b2 && compare_poly_qi t1 t2
  | _, _ -> false;;


(* Fonction de vérification de l'algorithme d'Euclide étendu *)
let verifier_euclide_etendu a b =
  let alpha, beta, p = euclide_etendu_qi a b in
  let left_side = add_poly_qi (mult_poly_qi alpha a) (mult_poly_qi beta b) in
  (left_side, p);;

(* Fonction pour convertir un polynôme en chaîne de caractères *)
let string_of_poly_qi p =
  String.concat " + " (List.map (fun (a, b) -> Printf.sprintf "(%s, %s)" (Q.to_string a) (Q.to_string b)) p);;

(* Exemple de test *)
let () =
  (* Exemple de polynômes dans Q(i)[X] *)
  let a = [(Q.of_int 1, Q.of_int 2); (Q.of_int 3, Q.of_int 4)] in
  let b = [(Q.of_int 5, Q.of_int 6); (Q.of_int 7, Q.of_int 8)] in

  (* Vérification de l'algorithme d'Euclide étendu *)
  let (left_side, p) = verifier_euclide_etendu a b in
  Printf.printf "alpha * A + beta * B = %s\n" (string_of_poly_qi left_side);
  Printf.printf "P = %s\n" (string_of_poly_qi p);
  assert (compare_poly_qi left_side p);

  (* Tests supplémentaires *)
  let test_cases = [
    ([(Q.of_int 1, Q.of_int 0)], [(Q.of_int 0, Q.of_int 1)]);
    ([(Q.of_int 2, Q.of_int 3)], [(Q.of_int 4, Q.of_int 5)]);
    ([(Q.of_int 6, Q.of_int 7)], [(Q.of_int 8, Q.of_int 9)]);
  ] in

  List.iter (fun (a, b) ->
    let (left_side, p) = verifier_euclide_etendu a b in
    assert (compare_poly_qi left_side p);
    Printf.printf "Test passed for A = %s, B = %s\n" (string_of_poly_qi a) (string_of_poly_qi b)
  ) test_cases;;

  (* EXERCIE 133333333333333333*)

  exception Division_par_zero

let rec diviser_poly_qi p1 p2 =
  if  est_polynome_vide p2 then raise Division_par_zero
  else
    let rec diviser_aux r1 r2 =
      if est_polynome_vide r1 || (of_int (List.length r1)) < (of_int (List.length r2))  then ([], r1)
      else
        let q_mono = monomial_quotient (List.hd r1) (List.hd r2) in
        let q_poly = [(q_mono)] in
        let r' = soustraire_poly_qi r1 (mult_mono_poly_qi q_mono r2) in
        let (q', r'') = diviser_aux r' r2 in
        (q_poly @ q', r'')
    in
    diviser_aux p1 p2;;

let normaliser_reste reste degre_B =
    multXn_poly_qi reste (to_int (degre_B + one));;

      let calculer_Q_R poly_A poly_B =
        let (q, reste) = diviser_poly_qi poly_A poly_B in
        let degre_B = degre_poly_qi poly_B in
        let r = normaliser_reste reste (of_int degre_B) in
        (q, r);;
      


        