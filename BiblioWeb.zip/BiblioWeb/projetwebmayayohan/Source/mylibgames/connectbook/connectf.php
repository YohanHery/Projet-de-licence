<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connect the Friends</title>
    <link rel="stylesheet" href="css/stylectf.css">
</head>

<body>
    <div id="score" class="score-display">Score: 0</div>
    <div id="lives" class="lives-display"></div>
    <canvas id="gameCanvas"></canvas>
    <script src="js/game.js"></script>
</body>

</html>