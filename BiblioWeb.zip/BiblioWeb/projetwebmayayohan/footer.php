<!-- footer.php -->
<footer>
    <div class="footer-container">
        <div class="social-media">
            <a href="./Source/mylibgames/flappybird/main.php" target="_blank">Twitter
            </a>
            <a href="./Source/mylibgames/connectbook/mainctf.php" target="_blank">Facebook
            </a>
          
        </div>
        <p>&copy; 2024 MyLib. Tous droits réservés.</p>
    </div>
</footer>
