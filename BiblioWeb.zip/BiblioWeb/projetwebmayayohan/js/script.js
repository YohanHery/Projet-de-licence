let carousel = document.getElementById('carousel');
let carouselButtonNext = document.querySelector('.carousel-button.next');
let carouselButtonPrev = document.querySelector('.carousel-button.prev');

function nextSlide() {
    carousel.scrollLeft += carousel.offsetWidth;
}

function prevSlide() {
    carousel.scrollLeft -= carousel.offsetWidth;
}