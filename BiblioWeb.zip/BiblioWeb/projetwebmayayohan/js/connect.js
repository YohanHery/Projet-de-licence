document.addEventListener("DOMContentLoaded", function () {
    var csrfToken = "<?php echo $_SESSION['token']; ?>";
    var form = document.getElementById("register");
    var input = document.createElement("input");
    input.type = "hidden";
    input.name = "token";
    input.value = csrfToken;
    form.appendChild(input);
});
