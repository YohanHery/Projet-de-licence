window.addEventListener('load', function () {
  const signUpButton = document.getElementById('signUp');
  const logAdminButton = document.getElementById('logadmin');
  const container = document.getElementById('container');

  signUpButton.addEventListener('click', () => {
    container.classList.add("right-panel-active");
  });

  logAdminButton.addEventListener('click', () => {
    container.classList.remove("right-panel-active");
  });
});
